#!/usr/bin/env python3
"""Build 19 - derive mod part sprites FROM vanilla textures.

The user compared vanilla items vs mod part items (screenshot) and asked to
make the mod parts "as close as possible". The mod pipeline is
grayscale texture x constant tint, so exact vanilla palettes (multi-hue)
are impossible - but vanilla tool sprites share pixel geometry across
materials (same head/stick positions for iron/gold/copper). That makes
this a rank-1 factorization:  vanilla_px[m][p] ~ tint[m] * gray[p]

We solve it with alternating least squares over the REAL vanilla sprites
(iron + gold + copper per tool family; blaze + breeze for the rod/handle),
giving:
  - one shared grayscale head sprite per tool (vanilla geometry, vanilla
    value structure, incl. the dark outline the old sprites lacked)
  - per-material tints that minimize pixel error against vanilla

Outputs:
  - new textures: pickaxe_head/axe_head/shovel_head/hoe_head/sword_head/handle
    (old ones backed up to work/backup_sprites/)
  - work/preview/parts_preview.png  (vanilla vs reconstruction sheets)
  - computed tints printed as hex + decimal for ModMaterials + tool JSONs
"""
from PIL import Image, ImageDraw
import os, shutil

VAN = "/home/z/my-project/work/vanilla/all_items"
TEX = "/home/z/my-project/modular-dreams/src/main/resources/assets/modular_dreams/textures/item"
BACKUP = "/home/z/my-project/work/backup_sprites"
PREVIEW = "/home/z/my-project/work/preview"
os.makedirs(BACKUP, exist_ok=True)
os.makedirs(PREVIEW, exist_ok=True)

def load(name):
    return Image.open(f"{VAN}/{name}.png").convert("RGBA")

def lum(px):
    return 0.299 * px[0] + 0.587 * px[1] + 0.114 * px[2]

TOOLS = ["pickaxe", "axe", "shovel", "hoe", "sword"]  # iron/gold/copper variants exist
MAT_SPRITE = {"iron": "iron", "gold": "golden", "copper": "copper"}

def head_mask(iron_img):
    """Iron head pixels = gray pixels (stick is brown, max-min > 20)."""
    mask = {}
    for y in range(16):
        for x in range(16):
            p = iron_img.getpixel((x, y))
            if p[3] > 0 and (max(p[:3]) - min(p[:3])) <= 10:
                mask[(x, y)] = p
    return mask

def alsq(pixel_targets, g_init, iters=14):
    """pixel_targets: {mat: {pos: rgb}} -> returns {mat: (r,g,b)}, {pos: g}.
    Scale-drift guard: after every iteration the brightest tint component
    across all materials is pinned to 255 (products g*tint unchanged), so
    the factorization cannot collapse to T->0 / g->255."""
    g = dict(g_init)
    tints = {}
    for it in range(iters):
        # tints given g (luminance-weighted: bright faces matter most at GUI scale)
        # model: p_c = (g/255) * T_c
        tints = {}
        for m, pxs in pixel_targets.items():
            num = [0.0, 0.0, 0.0]; den = 0.0
            for pos, p in pxs.items():
                gv = g[pos]
                w = lum(p) + 30.0
                for c in range(3):
                    num[c] += w * gv * p[c]
                den += w * gv * gv
            tints[m] = tuple(max(0.0, min(255.0, 255.0 * n / den)) for n in num)
        # g given tints
        new_g = {}
        for pos in g:
            num = 0.0; den = 0.0
            for m, pxs in pixel_targets.items():
                p = pxs[pos]; t = tints[m]
                w = lum(p) + 30.0
                for c in range(3):
                    num += w * t[c] * p[c]
                    den += w * t[c] * t[c]
            new_g[pos] = max(0.0, min(255.0, 255.0 * num / den))
        g = new_g
        # pin scale: brightest tint component = 255
        peak = max(max(t) for t in tints.values())
        if peak > 0:
            k = 255.0 / peak
            tints = {m: tuple(v * k for v in t) for m, t in tints.items()}
            g = {pos: max(0.0, min(255.0, v / k)) for pos, v in g.items()}
    return tints, {pos: int(round(v)) for pos, v in g.items()}

def error(pxs, tint, g):
    tot = 0.0; n = 0
    for pos, p in pxs.items():
        for c in range(3):
            tot += abs(round(g[pos] / 255.0 * tint[c]) - p[c])
            n += 1
    return tot / n

results = {}
# ---------------- tool heads ----------------
for tool in TOOLS:
    iron = load(f"{MAT_SPRITE['iron']}_{tool}")
    mask = head_mask(iron)
    targets = {}
    for m, pref in MAT_SPRITE.items():
        img = load(f"{pref}_{tool}")
        pxs = {pos: img.getpixel(pos)[:3] for pos in mask}
        if len(pxs) != len(mask):
            print(f"  !! {pref}_{tool}: geometry mismatch")
        targets[m] = pxs
    g_init = {pos: lum(p) for pos, p in mask.items()}
    tints, g = alsq(targets, g_init)
    results[tool] = (mask, g, tints)
    print(f"== {tool}_head: {len(mask)} px")
    for m in ("gold", "copper"):
        t = tuple(int(round(v)) for v in tints[m])
        print(f"   {m} tint #{t[0]:02X}{t[1]:02X}{t[2]:02X} {t}  err={error(targets[m], tints[m], g):.1f}")
    print(f"   iron tint #{int(round(tints['iron'][0])):02X}..  err={error(targets['iron'], tints['iron'], g):.1f}")

# ---------------- handle from rods ----------------
blaze = load("blaze_rod"); breeze = load("breeze_rod")
rod_px = sorted({(x, y) for y in range(16) for x in range(16) if blaze.getpixel((x, y))[3] > 0})
rod_targets = {
    "blaze": {(x, y): blaze.getpixel((x, y))[:3] for (x, y) in rod_px},
    "breeze": {(x, y): breeze.getpixel((x, y))[:3] for (x, y) in rod_px},
}
g_init = {pos: lum(rod_targets["blaze"][pos]) for pos in rod_px}
rod_tints, rod_g = alsq(rod_targets, g_init)
for m in ("blaze", "breeze"):
    t = tuple(int(round(v)) for v in rod_tints[m])
    print(f"== handle/rod: {len(rod_px)} px, {m} tint #{t[0]:02X}{t[1]:02X}{t[2]:02X} {t}  err={error(rod_targets[m], rod_tints[m], rod_g):.1f}")

# ---------------- write textures ----------------
def write_tex(name, mask, g):
    path = f"{TEX}/{name}.png"
    if os.path.exists(path):
        shutil.copy(path, f"{BACKUP}/{name}.png")
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for (x, y), p in mask.items():
        v = g[(x, y)]
        img.putpixel((x, y), (v, v, v, 255))
    img.save(path)
    print(f"wrote {name}.png ({len(mask)} px)")

for tool in TOOLS:
    mask, g, _ = results[tool]
    write_tex(f"{tool}_head", mask, g)
write_tex("handle", {(x, y): blaze.getpixel((x, y)) for (x, y) in rod_px}, rod_g)

# ---------------- preview sheets ----------------
S = 8  # scale
def S32(img):
    return img.resize((16 * S, 16 * S), Image.NEAREST)

sheet = Image.new("RGBA", (5 * 16 * S + 60, 2 * 16 * S + 40), (40, 40, 40, 255))
d = ImageDraw.Draw(sheet)

def cell(col, row, build, label):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    build(img)
    sheet.alpha_composite(S32(img), (10 + col * (16 * S + 10), 24 + row * (16 * S + 10)))
    d.text((10 + col * (16 * S + 10), 8 + row * (16 * S + 10)), label, fill=(255, 255, 255, 255))

def recon_builder(mask, g, tint):
    def b(img):
        for (x, y) in mask:
            v = g[(x, y)]
            img.putpixel((x, y), (min(255, round(v / 255 * tint[0])),
                                  min(255, round(v / 255 * tint[1])),
                                  min(255, round(v / 255 * tint[2])), 255))
    return b

def vanilla_builder(name):
    src = load(name)
    def b(img):
        for y in range(16):
            for x in range(16):
                img.putpixel((x, y), src.getpixel((x, y)))
    return b

def assembled_builder(van_name, mask, g, tint):
    """vanilla stick + reconstructed head (simulates the assembled mod tool)."""
    src = load(van_name)
    stick = head_mask(src)  # not used; stick = opaque minus head mask of iron
    iron = load(van_name.replace("golden", "iron").replace("copper", "iron"))
    hm = set(head_mask(iron).keys())
    def b(img):
        for y in range(16):
            for x in range(16):
                p = src.getpixel((x, y))
                if p[3] > 0 and (x, y) not in hm:
                    img.putpixel((x, y), p)  # vanilla stick
        for (x, y) in mask:
            v = g[(x, y)]
            img.putpixel((x, y), (min(255, round(v / 255 * tint[0])),
                                  min(255, round(v / 255 * tint[1])),
                                  min(255, round(v / 255 * tint[2])), 255))
    return b

# row 0: pickaxe (gold), axe (copper), pickaxe (copper), axe (gold), blaze rod
gm = tuple(int(round(v)) for v in results["pickaxe"][2]["gold"])
cm_axe = tuple(int(round(v)) for v in results["axe"][2]["copper"])
cm_pick = tuple(int(round(v)) for v in results["pickaxe"][2]["copper"])
gm_axe = tuple(int(round(v)) for v in results["axe"][2]["gold"])
bt = tuple(int(round(v)) for v in rod_tints["blaze"])
zt = tuple(int(round(v)) for v in rod_tints["breeze"])

cell(0, 0, vanilla_builder("golden_pickaxe"), "van gold pick")
cell(1, 0, assembled_builder("golden_pickaxe", *results["pickaxe"][:2], gm), "sim mod gold")
cell(2, 0, vanilla_builder("copper_axe"), "van copper axe")
cell(3, 0, assembled_builder("copper_axe", *results["axe"][:2], cm_axe), "sim mod copper")
cell(4, 0, recon_builder(*results["pickaxe"][:2], cm_pick), "copper head only")
# row 1: heads only + rods
cell(0, 1, recon_builder(*results["pickaxe"][:2], gm), "gold head only")
cell(1, 1, recon_builder(*results["axe"][:2], cm_axe), "copper axe head")
cell(2, 1, vanilla_builder("blaze_rod"), "van blaze rod")
cell(3, 1, recon_builder({(x, y): blaze.getpixel((x, y)) for (x, y) in rod_px}, rod_g, bt), "sim mod blaze")
cell(4, 1, recon_builder({(x, y): blaze.getpixel((x, y)) for (x, y) in rod_px}, rod_g, zt), "sim mod breeze")

sheet.save(f"{PREVIEW}/parts_preview.png")
print("preview saved")

# ---------------- tints for code ----------------
print("\n--- TINTS FOR CODE (decimal) ---")
print(f"gold      #{gm[0]:02X}{gm[1]:02X}{gm[2]:02X} = {gm[0]*65536 + gm[1]*256 + gm[2]}")
print(f"copper    #{cm_pick[0]:02X}{cm_pick[1]:02X}{cm_pick[2]:02X} = {cm_pick[0]*65536 + cm_pick[1]*256 + cm_pick[2]}")
print(f"blaze_rod #{bt[0]:02X}{bt[1]:02X}{bt[2]:02X} = {bt[0]*65536 + bt[1]*256 + bt[2]}")
print(f"breeze_rod #{zt[0]:02X}{zt[1]:02X}{zt[2]:02X} = {zt[0]*65536 + zt[1]*256 + zt[2]}")
