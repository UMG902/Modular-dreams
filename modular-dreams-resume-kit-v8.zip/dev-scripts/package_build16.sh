#!/usr/bin/env bash
# Build 16 packaging: fresh deliverables into download/
set -euo pipefail

PROJ=/home/z/my-project/mod/modular-dreams
DL=/home/z/my-project/download
WORK=/home/z/my-project
BUILD_DIR=$WORK/work/pkg16

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/modular-dreams-src"

# 1) copy the built jars
cp "$PROJ/build/libs/modular-dreams-1.6.0.jar" "$BUILD_DIR/"
cp "$PROJ/build/libs/modular-dreams-1.6.0-sources.jar" "$BUILD_DIR/"

# 2) full readable source tree
cd "$PROJ"
rsync -a --exclude build --exclude .gradle --exclude run \
        src gradle.properties build.gradle settings.gradle \
        "$BUILD_DIR/modular-dreams-src/" 2>/dev/null || {
  cp -r src "$BUILD_DIR/modular-dreams-src/"
  cp gradle.properties build.gradle settings.gradle "$BUILD_DIR/modular-dreams-src/" 2>/dev/null || true
}

# 3) notes + worklog
cp "$WORK/scripts/build16_notes.txt" "$BUILD_DIR/BUILD-16-NOTES.txt"
cp "$WORK/worklog.md" "$BUILD_DIR/worklog.md"

# 4) rebuild the zip from scratch
cd "$BUILD_DIR"
rm -f "$DL/modular-dreams-ALL-IN-ONE.zip"
zip -qr "$DL/modular-dreams-ALL-IN-ONE.zip" .

# 5) bare jars + notes into download/
cp "$BUILD_DIR/modular-dreams-1.6.0.jar" "$DL/"
cp "$BUILD_DIR/modular-dreams-1.6.0-sources.jar" "$DL/"
cp "$BUILD_DIR/BUILD-16-NOTES.txt" "$DL/"

# 6) drop stale 1.5.0 deliverables
rm -f "$DL/modular-dreams-1.5.0.jar" "$DL/modular-dreams-1.5.0-sources.jar" "$DL/BUILD-15-NOTES.txt"

echo "--- packaged: ---"
python3 - <<'EOF'
import zipfile, os, hashlib
dl = '/home/z/my-project/download'
for f in sorted(os.listdir(dl)):
    p = os.path.join(dl, f)
    h = hashlib.md5(open(p, 'rb').read()).hexdigest()[:10]
    print(f"{os.path.getsize(p):>9,} bytes  md5:{h}  {f}")
z = zipfile.ZipFile(os.path.join(dl, 'modular-dreams-ALL-IN-ONE.zip'))
print('zip entries:', len(z.namelist()))
EOF
