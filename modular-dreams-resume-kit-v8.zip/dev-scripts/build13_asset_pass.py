#!/usr/bin/env python3
"""Build 13 asset pass:
- create the universal handle texture (copy of the old pickaxe handle stick)
- delete per-tool handle textures and all mace textures
- rewrite the hand-written tool item definitions (handle layer -> universal)
- delete the mace tool definition
"""
import json
import os
import shutil

ROOT = "/home/z/my-project/mod/modular-dreams/src/main/resources/assets/modular_dreams"
ITEMS = os.path.join(ROOT, "textures", "item")
DEFS = os.path.join(ROOT, "items")

# 1) universal handle texture: reuse the old pickaxe handle stick art
handle_png = os.path.join(ITEMS, "handle.png")
if not os.path.exists(handle_png):
    shutil.copyfile(os.path.join(ITEMS, "pickaxe_handle.png"), handle_png)
    print("created textures/item/handle.png")
else:
    print("textures/item/handle.png already exists")

# 2) delete textures of removed part shapes (per-tool handles + whole mace)
removed = [
    "axe_handle.png", "hoe_handle.png", "pickaxe_handle.png", "shovel_handle.png",
    "mace_head.png", "mace_binding.png", "mace_handle.png",
]
for name in removed:
    path = os.path.join(ITEMS, name)
    if os.path.exists(path):
        os.remove(path)
        print("deleted textures/item/" + name)

# the old part-builder pattern icon of the mace head (folder is unreferenced legacy)
mace_pattern = os.path.join(ROOT, "textures", "gui", "pattern", "mace_head.png")
if os.path.exists(mace_pattern):
    os.remove(mace_pattern)
    print("deleted textures/gui/pattern/mace_head.png")

# 3) rewrite the handle layer of the four universal-handle tools
for tool in ["pickaxe", "axe", "shovel", "hoe"]:
    old_part = f"{tool}_handle"
    path = os.path.join(DEFS, f"modular_{tool}.json")
    with open(path) as f:
        raw = f.read()
    raw = raw.replace(f'"part": "{old_part}"', '"part": "handle"')
    raw = raw.replace(f'"model": "modular_dreams:{old_part}"', '"model": "modular_dreams:handle"')
    data = json.loads(raw)  # validate
    layers = [layer["part"] for layer in data["model"]["layers"]]
    # render order: handle lowest, head above, binding on top
    assert layers == ["handle", f"{tool}_head", f"{tool}_binding"], layers
    with open(path, "w") as f:
        f.write(raw)
    print(f"rewrote items/modular_{tool}.json -> layers {layers}")

# 4) the mace has no definition anymore
mace_def = os.path.join(DEFS, "modular_mace.json")
if os.path.exists(mace_def):
    os.remove(mace_def)
    print("deleted items/modular_mace.json")

print("done")
