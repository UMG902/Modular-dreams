#!/usr/bin/env bash
# Build 15 REDELIVERY: recreate every deliverable in download/ with fresh
# timestamps so the site registers new files this session.
set -euo pipefail

PROJ=/home/z/my-project/mod/modular-dreams
DL=/home/z/my-project/download
WORK=/home/z/my-project
BUILD_DIR=$WORK/work/pkg15

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/modular-dreams-src"

# 1) fresh copies of the built jars
cp "$PROJ/build/libs/modular-dreams-1.5.0.jar" "$BUILD_DIR/"
cp "$PROJ/build/libs/modular-dreams-1.5.0-sources.jar" "$BUILD_DIR/"

# 2) full readable source tree
cd "$PROJ"
rsync -a --exclude build --exclude .gradle --exclude run \
        src gradle.properties build.gradle settings.gradle \
        "$BUILD_DIR/modular-dreams-src/" 2>/dev/null || {
  cp -r src "$BUILD_DIR/modular-dreams-src/"
  cp gradle.properties build.gradle settings.gradle "$BUILD_DIR/modular-dreams-src/" 2>/dev/null || true
}

# 3) notes + up-to-date worklog
cp "$WORK/scripts/build15_notes.txt" "$BUILD_DIR/BUILD-15-NOTES.txt"
cp "$WORK/worklog.md" "$BUILD_DIR/worklog.md"

# 4) rebuild the zip from scratch
cd "$BUILD_DIR"
rm -f "$DL/modular-dreams-ALL-IN-ONE.zip"
zip -qr "$DL/modular-dreams-ALL-IN-ONE.zip" .

# 5) bare jars + notes into download/
cp "$BUILD_DIR/modular-dreams-1.5.0.jar" "$DL/"
cp "$BUILD_DIR/modular-dreams-1.5.0-sources.jar" "$DL/"
cp "$BUILD_DIR/BUILD-15-NOTES.txt" "$DL/"

echo "--- redelivered: ---"
python3 - <<'EOF'
import zipfile, os, hashlib
dl = '/home/z/my-project/download'
for f in sorted(os.listdir(dl)):
    p = os.path.join(dl, f)
    h = hashlib.md5(open(p, 'rb').read()).hexdigest()[:10]
    print(f"{os.path.getsize(p):>9,} bytes  md5:{h}  {f}")
z = zipfile.ZipFile(os.path.join(dl, 'modular-dreams-ALL-IN-ONE.zip'))
tops = {}
for n in z.namelist():
    top = n.split('/')[0]
    tops[top] = tops.get(top, 0) + 1
print('--- zip contents by top-level: ---')
for k, v in sorted(tops.items()):
    print(f"{v:5d}  {k}")
print("zip total:", len(z.namelist()))
EOF
