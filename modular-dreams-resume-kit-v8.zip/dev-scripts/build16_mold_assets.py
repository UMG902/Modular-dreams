#!/usr/bin/env python3
"""Build 16 asset pass: carved mold cutouts + universal binding item texture.

1. Creates textures/item/binding.png (the universal binding item icon) from
   the pickaxe binding shape.
2. For every shapeable part (MoldShape values except NONE) generates a CUTOUT
   top texture for the clay and the terracotta mold: the mold's top texture
   with the part's silhouette REMOVED (alpha = 0) - a real mold cavity.
3. Writes one shaped block model per mold x part (copy of the flat 1-px
   cutting-board model, top face swapped to the cutout texture,
   render_type: minecraft:cutout).
4. Rewrites both mold blockstates with the full shape=... variant list.
"""
import json
import os
import shutil
from PIL import Image

ROOT = '/home/z/my-project/mod/modular-dreams/src/main/resources/assets/modular_dreams'
TEX_ITEM = os.path.join(ROOT, 'textures/item')
TEX_BLOCK = os.path.join(ROOT, 'textures/block')
MODELS = os.path.join(ROOT, 'models/block')
BLOCKSTATES = os.path.join(ROOT, 'blockstates')

# MoldShape order (minus NONE) - must match the enum + blockstates
SHAPES = ['handle', 'binding', 'pickaxe_head', 'axe_head', 'shovel_head',
          'hoe_head', 'sword_head', 'sword_binding', 'spear_head', 'spear_binding']
MOLDS = {
    'clay_mold': 'clay_mold_top',
    'terracotta_mold': 'terracotta_mold_top',
}
HOLE_ALPHA_THRESHOLD = 32  # part pixels with alpha above this carve a hole

def ensure_dir(p):
    os.makedirs(p, exist_ok=True)

# ---------------------------------------------------------------- 1) binding.png
dst_binding = os.path.join(TEX_ITEM, 'binding.png')
if not os.path.exists(dst_binding):
    shutil.copy(os.path.join(TEX_ITEM, 'pickaxe_binding.png'), dst_binding)
    print('created textures/item/binding.png (copy of pickaxe_binding.png)')
else:
    print('textures/item/binding.png already exists')

# ---------------------------------------------------------------- 2) cutout tops
for part_id in SHAPES:
    part_path = os.path.join(TEX_ITEM, f'{part_id}.png')
    part = Image.open(part_path).convert('RGBA')
    assert part.size == (16, 16), f'{part_path} is {part.size}, expected 16x16'
    part_alpha = part.getchannel('A').load()
    for mold, top_name in MOLDS.items():
        top_path = os.path.join(TEX_BLOCK, f'{top_name}.png')
        top = Image.open(top_path).convert('RGBA')
        assert top.size == (16, 16), f'{top_path} is {top.size}, expected 16x16'
        out = top.copy()
        px = out.load()
        holes = 0
        for y in range(16):
            for x in range(16):
                if part_alpha[x, y] > HOLE_ALPHA_THRESHOLD:
                    px[x, y] = (0, 0, 0, 0)
                    holes += 1
        out_path = os.path.join(TEX_BLOCK, f'{top_name}_shaped_{part_id}.png')
        out.save(out_path)
        print(f'{os.path.basename(out_path)}: {holes} px carved out')

# ---------------------------------------------------------------- 3) shaped models
ELEMENTS = {
    "from": [0, 0, 0],
    "to": [16, 1, 16],
    "faces": {
        "down":  {"texture": "#side", "uv": [0, 15, 16, 16], "cullface": "down"},
        "up":    {"texture": "#top",  "uv": [0, 0, 16, 16]},
        "north": {"texture": "#side", "uv": [0, 0, 16, 1], "cullface": "down"},
        "south": {"texture": "#side", "uv": [0, 0, 16, 1], "cullface": "down"},
        "west":  {"texture": "#side", "uv": [0, 0, 16, 1], "cullface": "down"},
        "east":  {"texture": "#side", "uv": [0, 0, 16, 1], "cullface": "down"},
    },
}

for mold, top_name in MOLDS.items():
    side_name = f'{mold}_side'
    for part_id in SHAPES:
        model = {
            "parent": "minecraft:block/block",
            "render_type": "minecraft:cutout",
            "textures": {
                "particle": f"modular_dreams:block/{top_name}",
                "top": f"modular_dreams:block/{top_name}_shaped_{part_id}",
                "side": f"modular_dreams:block/{side_name}",
            },
            "elements": [ELEMENTS],
        }
        path = os.path.join(MODELS, f'{mold}_shaped_{part_id}.json')
        with open(path, 'w') as f:
            json.dump(model, f, indent=2)
            f.write('\n')
        print(f'model {os.path.basename(path)}')

# ---------------------------------------------------------------- 4) blockstates
for mold in MOLDS:
    variants = {}
    variants["shape=none"] = {"model": f"modular_dreams:block/{mold}"}
    for part_id in SHAPES:
        variants[f"shape={part_id}"] = {"model": f"modular_dreams:block/{mold}_shaped_{part_id}"}
    state = {"variants": variants}
    path = os.path.join(BLOCKSTATES, f'{mold}.json')
    with open(path, 'w') as f:
        json.dump(state, f, indent=2)
        f.write('\n')
    print(f'blockstate {os.path.basename(path)}: {len(variants)} variants')

print('DONE')
