#!/usr/bin/env python3
"""Build 13 asset audit: reference resolution + build 13 specifics
(universal handle, mace removal, persistent assembly table, GUI blit fix)."""
import io
import json
import sys
import zipfile

from PIL import Image

JAR = "/home/z/my-project/mod/modular-dreams/build/libs/modular-dreams-1.3.0.jar"

zf = zipfile.ZipFile(JAR)
names = set(zf.namelist())
missing = []
errors = []

json_files = [n for n in names if n.endswith(".json")]

for name in json_files:
    try:
        text = zf.read(name).decode("utf-8")
        data = json.loads(text)
    except Exception:
        continue

    # 1. item definitions reference models
    if "/items/" in name:
        def walk(node):
            if isinstance(node, dict):
                if "model" in node and isinstance(node["model"], str):
                    model = node["model"]
                    if model.startswith(("minecraft:", "modular_dreams:")):
                        ns, p = model.split(":", 1)
                        target = f"assets/{ns}/models/{p}.json"
                        if target not in names:
                            missing.append((name, model))
                for v in node.values():
                    walk(v)
            elif isinstance(node, list):
                for v in node:
                    walk(v)
        walk(data)

    # 2. blockstates reference block models
    if "/blockstates/" in name:
        def walk_bs(node):
            if isinstance(node, dict):
                if "model" in node and isinstance(node["model"], str):
                    model = node["model"]
                    if model.startswith("modular_dreams:"):
                        ns, p = model.split(":", 1)
                        target = f"assets/{ns}/models/{p}.json"
                        if target not in names:
                            missing.append((name, model))
                for v in node.values():
                    walk_bs(v)
            elif isinstance(node, list):
                for v in node:
                    walk_bs(v)
        walk_bs(data)

    # 3. models reference textures (own namespace only)
    if "/models/" in name and isinstance(data, dict):
        for tex in data.get("textures", {}).values():
            if isinstance(tex, str) and tex.startswith("modular_dreams:"):
                ns, p = tex.split(":", 1)
                target = f"assets/{ns}/textures/{p}.png"
                if target not in names:
                    missing.append((name, tex))

print(f"jar entries: {len(names)}")
print(f"missing references: {len(missing)}")
for src, ref in missing[:20]:
    print(f"  MISSING {ref}   (in {src})")


def load(path):
    return json.loads(zf.read(path).decode("utf-8"))


# --- build 12 checks still in force ---

for mold in ("clay_mold", "terracotta_mold"):
    model = load(f"assets/modular_dreams/models/block/{mold}.json")
    elems = model.get("elements", [])
    if len(elems) != 1:
        errors.append(f"{mold} model has {len(elems)} elements, expected 1")
        continue
    el = elems[0]
    if el["from"][1] != 0 or el["to"][1] != 1:
        errors.append(f"{mold} element is {el['from']}..{el['to']}, expected y 0..1 (1 px tall)")

if "assets/modular_dreams/textures/gui/melting_upgrade.png" not in names:
    errors.append("missing textures/gui/melting_upgrade.png")
if "data/modular_dreams/loot_table/blocks/terracotta_mold.json" not in names:
    errors.append("no loot table for terracotta_mold")
lang = load("assets/modular_dreams/lang/en_us.json")
if "container.modular_dreams.melting_upgrade" not in lang:
    errors.append("lang missing container.modular_dreams.melting_upgrade")

# --- build 13 checks: version + mace removal ---

fmf = load("fabric.mod.json")
if fmf.get("version") != "1.3.0":
    errors.append(f"fabric.mod.json version is {fmf.get('version')}, expected 1.3.0")

mace_strings = [
    "modular_mace", "mace_head", "mace_binding", "mace_handle",
    "equipment.modular_dreams.mace", "guide.modular_dreams.tools.mace",
]
for name in json_files:
    try:
        text = zf.read(name).decode("utf-8")
    except Exception:
        continue
    for s in mace_strings:
        if s in text:
            errors.append(f"stale mace reference '{s}' in {name}")

# mace classes must be gone from the code
for cls in list(names):
    if "MACE" in cls.upper() and cls.endswith(".class") and "ModularToolItem" not in cls:
        if "maceBehavior" in cls or "ModularToolType$MACE" in cls:
            errors.append(f"stale mace class {cls}")
if any("ModularToolType$MACE" in n for n in names):
    errors.append("ModularToolType.MACE enum constant still compiled")

# --- build 13 checks: universal handle ---

# part item definitions: 9 materials per handle part (wood/stone/flint/bone/
# blaze_rod/breeze_rod + copper/iron/gold), no per-tool handles except sword/spear
HANDLE_MATS = ["wood", "stone", "flint", "bone", "blaze_rod", "breeze_rod",
               "copper", "iron", "gold"]
for mat in HANDLE_MATS:
    for part in ("handle", "sword_handle", "spear_handle"):
        if f"assets/modular_dreams/items/{mat}_{part}.json" not in names:
            errors.append(f"missing part item definition {mat}_{part}")
for tool in ("pickaxe", "axe", "shovel", "hoe"):
    if f"assets/modular_dreams/items/iron_{tool}_handle.json" in names:
        errors.append(f"stale per-tool handle definition iron_{tool}_handle")

# tool layer order: universal handle -> head -> binding (sword/spear own handles)
for tool in ("pickaxe", "axe", "shovel", "hoe", "sword", "spear"):
    d = load(f"assets/modular_dreams/items/modular_{tool}.json")
    parts = [l["part"] for l in d["model"]["layers"]]
    handle = f"{tool}_handle" if tool in ("sword", "spear") else "handle"
    expected = [handle, f"{tool}_head", f"{tool}_binding"]
    if parts != expected:
        errors.append(f"{tool} layers {parts} != {expected}")

# handle texture + model exist; per-tool handle textures gone
if "assets/modular_dreams/textures/item/handle.png" not in names:
    errors.append("missing textures/item/handle.png")
if "assets/modular_dreams/models/handle.json" not in names:
    errors.append("missing models/handle.json")
for tex in ("axe_handle", "hoe_handle", "pickaxe_handle", "shovel_handle",
            "mace_head", "mace_binding", "mace_handle"):
    if f"assets/modular_dreams/textures/item/{tex}.png" in names:
        errors.append(f"stale texture textures/item/{tex}.png")

# handle recipes: 6 part-builder materials x 3 handle part types
for recipe in zf.namelist():
    if recipe.startswith("data/modular_dreams/recipe/parts/") and "handle" in recipe:
        if any(t in recipe for t in ("pickaxe", "axe", "shovel", "hoe", "mace")):
            errors.append(f"stale handle recipe {recipe}")

# assembly table block entity ships in the jar
if "com/modulardreams/block/AssemblyTableBlockEntity.class" not in names:
    errors.append("AssemblyTableBlockEntity.class missing from the jar")
if "com/modulardreams/block/AssemblyTableBlock.class" not in names:
    errors.append("AssemblyTableBlock.class missing from the jar")

# --- build 13 checks: GUI texture dimensions (the 4x-size bug) ---
for gui in ("textures/gui/melting_upgrade.png", "textures/gui/container/assembly_table.png"):
    img = Image.open(io.BytesIO(zf.read(f"assets/modular_dreams/{gui}")))
    if img.size != (176, 166):
        errors.append(f"{gui} is {img.size}, expected (176, 166)")

# lang: universal handle name + no mace chapter
if lang.get("part.modular_dreams.handle") != "Handle":
    errors.append("lang missing part.modular_dreams.handle")
if "guide.modular_dreams.tools.spear.title" not in lang:
    errors.append("lang missing spear chapter (overzealous mace removal?)")

print(f"build 13 checks: {len(errors)} errors")
for e in errors:
    print(f"  ERROR {e}")

sys.exit(1 if (missing or errors) else 0)
