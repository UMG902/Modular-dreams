#!/usr/bin/env bash
# Builds MODULAR-DREAMS-RESUME-KIT.zip: full build-16 deliverables + resume prompt
# + worklog, then uploads it to tmpfiles.org, extracts the tokened direct URL and
# md5-verifies the download. One link to rule them all (insurance for a new chat).
set -euo pipefail
DL=/home/z/my-project/download
WORK=/home/z/my-project/work
UA="Mozilla/5.0 (X11; Linux x86_64) Firefox/128.0"
KIT=$WORK/resume-kit

rm -rf "$KIT"; mkdir -p "$KIT"

# 1) unpack the FULL pack (has jar, sources, notes, worklog, source tree)
unzip -q "$DL/MODULAR-DREAMS-B16-FULL.zip" -d "$KIT"

# 2) add the resume prompt + a tiny kit readme at the zip root
cp "$DL/RESUME-PROMPT.txt" "$KIT/RESUME-PROMPT.txt"
cat > "$KIT/README-KIT.txt" <<'EOF'
MODULAR DREAMS - RESUME KIT
1. Open RESUME-PROMPT.txt, copy its content, paste it as the first
   message of the new chat.
2. The new chat reads the same sandbox filesystem, so worklog.md and
   all scripts are already there - the prompt just points the way.
3. This kit is insurance: if the sandbox was ever wiped, everything
   needed (jar, sources, notes, full dev log) is inside the
   MODULAR-DREAMS-B16-FULL folder here.
EOF

# 3) refresh the worklog copy inside the pack to the latest state
cp /home/z/my-project/worklog.md "$KIT/MODULAR-DREAMS-B16-FULL/worklog.md"

# 4) zip it
ZIP=$DL/MODULAR-DREAMS-RESUME-KIT.zip
rm -f "$ZIP"
cd "$KIT"
zip -qr "$ZIP" RESUME-PROMPT.txt README-KIT.txt MODULAR-DREAMS-B16-FULL

# 5) upload + extract tokened direct URL + verify
PAGE=$(curl -sS -m 120 -F "file=@$ZIP" https://tmpfiles.org/api/v1/upload | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["url"])')
TOKEN=$(curl -sSL -m 30 -A "$UA" "$PAGE" | grep -oE 'https://tmpfiles.org/dl/[^"]*' | head -1)
[ -n "$TOKEN" ] || { echo "FAILED: no direct URL (page: $PAGE)"; exit 1; }
TMP=$(mktemp)
curl -sSL -m 180 -o "$TMP" "$TOKEN"
echo "--- verification ---"
md5sum "$ZIP" "$TMP" | awk '{print $1, $2}'
python3 - "$ZIP" "$TMP" <<'EOF'
import sys, os
a, b = (os.path.getsize(p) for p in sys.argv[1:3])
print(f"local {a:,} B vs downloaded {b:,} B -> {'MATCH' if a==b else 'MISMATCH'}")
EOF
rm -f "$TMP"
echo "LINK: $TOKEN"
