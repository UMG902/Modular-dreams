#!/usr/bin/env bash
# Build 16 redelivery ROUND 2: the box still didn't render for the old filenames.
# Strategy: remove every old-named file from download/ and ship the same verified
# content under brand-new unique filenames, so the platform cannot dedupe/suppress
# anything it has seen before. Two new artifacts only:
#   MODULAR-DREAMS-B16-FULL.zip      (everything: jar + sources + notes + source tree)
#   modular-dreams-1.6.0-b16-DIRECT.jar  (the bare mod jar, freshly named)
set -euo pipefail

PROJ=/home/z/my-project/mod/modular-dreams
DL=/home/z/my-project/download
WORK=/home/z/my-project
STAGE=$WORK/work/pkg16r2

# 0) clean slate: drop every previously-seen name
rm -f "$DL/modular-dreams-1.6.0.jar" \
      "$DL/modular-dreams-1.6.0-sources.jar" \
      "$DL/BUILD-16-NOTES.txt" \
      "$DL/modular-dreams-ALL-IN-ONE.zip" \
      "$DL/README.md"

rm -rf "$STAGE"
mkdir -p "$STAGE/MODULAR-DREAMS-B16-FULL/source"

# 1) verified built artifacts (untouched since the green build)
cp "$PROJ/build/libs/modular-dreams-1.6.0.jar" "$STAGE/MODULAR-DREAMS-B16-FULL/"
cp "$PROJ/build/libs/modular-dreams-1.6.0-sources.jar" "$STAGE/MODULAR-DREAMS-B16-FULL/"
cp "$WORK/scripts/build16_notes.txt" "$STAGE/MODULAR-DREAMS-B16-FULL/BUILD-16-NOTES.txt"

# 2) fresh-name readme inside the pack
cat > "$STAGE/MODULAR-DREAMS-B16-FULL/README-B16.txt" <<'EOF'
MODULAR DREAMS - BUILD 16 (v1.6.0) FULL PACK
============================================

modular-dreams-1.6.0.jar
    The mod. Put this single file into your .minecraft/mods folder
    (Fabric Loader 0.19.5+, Fabric API 0.161.0+26.3, Minecraft 26.3).

BUILD-16-NOTES.txt
    Everything that changed in build 16: melting furnace single output
    cell holding the mold, real carved cutout mold cavities, one universal
    Binding for pickaxe/axe/shovel/hoe (per-tool render textures kept),
    sword/spear bindings still separate, sword binding renamed to Guard.

modular-dreams-1.6.0-sources.jar + source/
    Readable source of build 16 (same tree, two formats).

worklog.md
    Full development log.

Note: this pack is a re-upload of the unchanged, verified build 16 jar
under new filenames because the download box failed to render for the
previous upload. The jar is byte-identical in content to the build
packaged on 2026-09-27 (fabric.mod.json version 1.6.0).
EOF

# 3) source tree + worklog
cd "$PROJ"
rsync -a --exclude build --exclude .gradle --exclude run \
        src gradle.properties build.gradle settings.gradle \
        "$STAGE/MODULAR-DREAMS-B16-FULL/source/" 2>/dev/null || {
  cp -r src "$STAGE/MODULAR-DREAMS-B16-FULL/source/"
  cp gradle.properties build.gradle settings.gradle "$STAGE/MODULAR-DREAMS-B16-FULL/source/" 2>/dev/null || true
}
cp "$WORK/worklog.md" "$STAGE/MODULAR-DREAMS-B16-FULL/worklog.md"

# 4) zip with the top-level folder inside
cd "$STAGE"
zip -qr "$DL/MODULAR-DREAMS-B16-FULL.zip" MODULAR-DREAMS-B16-FULL

# 5) direct jar copy under a fresh unique name
cp "$PROJ/build/libs/modular-dreams-1.6.0.jar" "$DL/modular-dreams-1.6.0-b16-DIRECT.jar"

echo "--- download/ now contains: ---"
python3 - <<'EOF'
import os, hashlib, zipfile, json, time
dl = '/home/z/my-project/download'
for f in sorted(os.listdir(dl)):
    p = os.path.join(dl, f)
    h = hashlib.md5(open(p, 'rb').read()).hexdigest()[:10]
    print(f"{os.path.getsize(p):>9,} bytes  md5:{h}  {f}")
jar = zipfile.ZipFile(os.path.join(dl, 'modular-dreams-1.6.0-b16-DIRECT.jar'))
print('direct jar entries:', len(jar.namelist()),
      '| version:', json.loads(jar.read('fabric.mod.json'))['version'])
pack = zipfile.ZipFile(os.path.join(dl, 'MODULAR-DREAMS-B16-FULL.zip'))
bad = pack.testzip()
print('pack entries:', len(pack.namelist()), '| zip integrity:', 'OK' if bad is None else f'CORRUPT: {bad}')
print('pack top-level:', sorted({n.split("/")[0] for n in pack.namelist()}))
EOF
