#!/usr/bin/env python3
"""Build 11 asset audit: verify every modular_dreams: reference inside the jar
resolves to an actual file, and check the Build 11 specifics."""
import json
import re
import sys
import zipfile

JAR = "/home/z/my-project/mod/modular-dreams/build/libs/modular-dreams-1.1.0.jar"

zf = zipfile.ZipFile(JAR)
names = set(zf.namelist())
refs_re = re.compile(r'"((?:modular_dreams|minecraft):[A-Za-z0-9_/.]+)"')

def resolve(ref, context):
    ns, path = ref.split(":", 1)
    if context == "blockstate_variant_model":
        return f"assets/{ns}/models/{path}.json"
    return None

missing = []
json_files = [n for n in names if n.endswith(".json")]

for name in json_files:
    try:
        data = json.loads(zf.read(name).decode("utf-8"))
    except Exception:
        continue

    text = zf.read(name).decode("utf-8")

    # 1. item definitions reference models
    if "/items/" in name:
        def walk(node):
            if isinstance(node, dict):
                if "model" in node and isinstance(node["model"], str):
                    model = node["model"]
                    if not (model.startswith("minecraft:") or model.startswith("modular_dreams:")):
                        return
                    if "minecraft:" in model and not model.startswith("minecraft:"):
                        return
                    ns, p = model.split(":", 1)
                    target = f"assets/{ns}/models/{p}.json"
                    if target not in names:
                        missing.append((name, model))
                for v in node.values():
                    walk(v)
            elif isinstance(node, list):
                for v in node:
                    walk(v)
        walk(data)

    # 2. blockstates reference block models
    if "/blockstates/" in name:
        def walk_bs(node):
            if isinstance(node, dict):
                if "model" in node and isinstance(node["model"], str):
                    model = node["model"]
                    if model.startswith("modular_dreams:"):
                        ns, p = model.split(":", 1)
                        target = f"assets/{ns}/models/{p}.json"
                        if target not in names:
                            missing.append((name, model))
                for v in node.values():
                    walk_bs(v)
            elif isinstance(node, list):
                for v in node:
                    walk_bs(v)
        walk_bs(data)

    # 3. models reference textures (own namespace only)
    if "/models/" in name and isinstance(data, dict):
        for tex in data.get("textures", {}).values():
            if tex.startswith("modular_dreams:"):
                ns, p = tex.split(":", 1)
                target = f"assets/{ns}/textures/{p}.png"
                if target not in names:
                    missing.append((name, tex))

# 4. loot tables referencing items are fine (minecraft namespace)

print(f"jar entries: {len(names)}")
print(f"missing references: {len(missing)}")
for src, ref in missing[:20]:
    print(f"  MISSING {ref}   (in {src})")

# --- build 11 specifics ---
errors = []

def load(path):
    return json.loads(zf.read(path).decode("utf-8"))

# blockstate present + uses vanilla models
bs = load("assets/modular_dreams/blockstates/melting_furnace.json")
variants = bs.get("variants", {})
if len(variants) != 8:
    errors.append(f"melting_furnace blockstate has {len(variants)} variants, expected 8")
if variants.get("facing=north,lit=true", {}).get("model") != "minecraft:block/furnace_on":
    errors.append("melting_furnace lit model wrong")

# loot table drops furnace
loot = load("data/modular_dreams/loot_table/blocks/melting_furnace.json")
if "minecraft:furnace" not in json.dumps(loot):
    errors.append("melting_furnace loot does not drop minecraft:furnace")

# pickaxe tag
tag = load("data/minecraft/tags/block/mineable/pickaxe.json")
if "modular_dreams:melting_furnace" not in tag.get("values", []):
    errors.append("melting_furnace missing from mineable/pickaxe")

# tool definitions layer order: handle, head, binding
for tool in ["axe", "hoe", "mace", "pickaxe", "shovel", "spear", "sword"]:
    d = load(f"assets/modular_dreams/items/modular_{tool}.json")
    parts = [l["part"] for l in d["model"]["layers"]]
    expected = [f"{tool}_handle", f"{tool}_head", f"{tool}_binding"]
    if parts != expected:
        errors.append(f"{tool} layers {parts} != {expected}")

# no item definition for the furnace block (no item form)
if "assets/modular_dreams/items/melting_furnace.json" in names:
    errors.append("melting_furnace has an item definition but should have none")

# lang: no melting_furnace block name needed; container title uses vanilla key
print(f"build 11 checks: {len(errors)} errors")
for e in errors:
    print(f"  ERROR {e}")

sys.exit(1 if (missing or errors) else 0)
