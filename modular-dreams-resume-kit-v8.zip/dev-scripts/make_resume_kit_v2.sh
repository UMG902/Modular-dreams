#!/usr/bin/env bash
# Resume kit v3 - repo edition: travels by URL, NOT by chat attachment.
# Zip layout restores /home/z/my-project/ directly:
#   RESUME-PROMPT.txt, README-KIT.txt, worklog.md, BUILD-16-NOTES.txt,
#   the two jars, modular-dreams/ (FULL gradle project incl. wrapper),
#   dev-scripts/ (asset generators, audits, packaging, tmpfiles uploader).
# Then uploads to tmpfiles.org, extracts the tokened direct URL, md5-verifies.
set -euo pipefail
PROJ=/home/z/my-project/mod/modular-dreams
DL=/home/z/my-project/download
WORK=/home/z/my-project/work
UA="Mozilla/5.0 (X11; Linux x86_64) Firefox/128.0"
KIT=$WORK/resume-kit-v3

rm -rf "$KIT"; mkdir -p "$KIT/modular-dreams" "$KIT/dev-scripts"

# 1) complete gradle project (src + wrapper + build files, no build artifacts)
cd "$PROJ"
rsync -a --exclude build --exclude .gradle --exclude run \
        src gradle.properties build.gradle settings.gradle \
        gradlew gradlew.bat gradle LICENSE README.md \
        "$KIT/modular-dreams/" 2>/dev/null || {
  cp -r src gradle "$KIT/modular-dreams/"
  cp gradle.properties build.gradle settings.gradle gradlew gradlew.bat LICENSE README.md "$KIT/modular-dreams/" 2>/dev/null || true
}

# 2) dev tooling + docs
cp /home/z/my-project/scripts/*.py /home/z/my-project/scripts/*.sh "$KIT/dev-scripts/" 2>/dev/null || true
cp /home/z/my-project/scripts/build16_notes.txt "$KIT/BUILD-16-NOTES.txt"
cp /home/z/my-project/worklog.md "$KIT/worklog.md"
cp "$DL/RESUME-PROMPT.txt" "$KIT/RESUME-PROMPT.txt"

# 3) compiled artifacts (known-good v1.6.0) - note: mod build/ was purged by
#    sandbox housekeeping, so source the VERIFIED copies:
#    jar from download/ (md5 e3374e8bce60647d118f995a2e501325),
#    sources jar from inside the FULL pack (md5 starts ae773c37d0).
cp "$DL/modular-dreams-1.6.0-b16-DIRECT.jar" "$KIT/modular-dreams-1.6.0-b16-DIRECT.jar"
unzip -o -j "$DL/MODULAR-DREAMS-B16-FULL.zip" \
      "MODULAR-DREAMS-B16-FULL/modular-dreams-1.6.0-sources.jar" -d "$KIT/" >/dev/null
echo "jar md5:      $(md5sum "$KIT/modular-dreams-1.6.0-b16-DIRECT.jar" | cut -d' ' -f1)"
echo "sources md5:  $(md5sum "$KIT/modular-dreams-1.6.0-sources.jar" | cut -d' ' -f1)"

# 4) kit readme
cat > "$KIT/README-KIT.txt" <<'EOF'
MODULAR DREAMS - RESUME KIT v3 (repo edition)
Platform facts: a new chat creates a NEW sandbox (nothing persists), AND
files uploaded into chat never reach the agent (known platform bug).
So this kit travels by LINK, not attachment:

1. Put this zip in a repo (GitHub is reachable from the sandbox firewall;
   a Release asset or a raw file both work) or any file host.
2. Open RESUME-PROMPT.txt, copy its content, paste it as the FIRST message
   of the new chat, replacing <KIT_URL> with the link to this zip.
3. The agent downloads it, unzips it to /home/z/my-project/, and that
   restores the complete gradle project (modular-dreams/, with wrapper),
   the dev history (worklog.md), build notes, the compiled v1.6.0 jars,
   and the dev tooling (dev-scripts/).
Contents:
  RESUME-PROMPT.txt            first-message prompt (self-contained)
  modular-dreams/              full source + gradle wrapper + datagen output
  worklog.md                   complete development log (tasks 1..16R6)
  BUILD-16-NOTES.txt           what build 16 changed
  modular-dreams-1.6.0-b16-DIRECT.jar   tested mod jar -> .minecraft/mods
  modular-dreams-1.6.0-sources.jar      readable source jar
  dev-scripts/                 generators, audits, packaging, uploader
EOF

# 5) zip, upload, extract tokened URL, verify md5
ZIP=$DL/MODULAR-DREAMS-RESUME-KIT-v3.zip
rm -f "$ZIP"
cd "$KIT"
zip -qr "$ZIP" .

PAGE=$(curl -sS -m 180 -F "file=@$ZIP" https://tmpfiles.org/api/v1/upload | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["url"])')
TOKEN=$(curl -sSL -m 30 -A "$UA" "$PAGE" | grep -oE 'https://tmpfiles.org/dl/[^"]*' | head -1)
[ -n "$TOKEN" ] || { echo "FAILED: no direct URL (page: $PAGE)"; exit 1; }
TMP=$(mktemp)
curl -sSL -m 300 -o "$TMP" "$TOKEN"
echo "--- verification ---"
md5sum "$ZIP" "$TMP" | awk '{print $1, $2}'
python3 - "$ZIP" "$TMP" <<'EOF'
import sys, os
a, b = (os.path.getsize(p) for p in sys.argv[1:3])
print(f"local {a:,} B vs downloaded {b:,} B -> {'MATCH' if a==b else 'MISMATCH'}")
EOF
rm -f "$TMP"
echo "LINK: $TOKEN"
echo "KIT SIZE: $(stat -c %s "$ZIP") bytes"
