#!/usr/bin/env python3
"""Build 17 asset audit: verifies every mold fix shipped in the jar.

1) Item definitions: select on modular_dreams:mold_part, 10 cases each,
   fallback to the base model, every referenced model present.
2) Blockstates: all 11 variants of both molds still point at existing models.
3) Block models: NO cullface:down on north/south/east/west faces (invisible
   sides bug); bottom face may keep it.
4) Lang: re-shape guide text present; 240 keys.
5) Carved top textures still ship (20 shaped top textures).
6) fabric.mod.json reports 1.7.0.
"""
import json
import sys
import zipfile

JAR = "/home/z/my-project/modular-dreams/build/libs/modular-dreams-1.7.0.jar"
SHAPES = [
    "handle", "binding", "pickaxe_head", "axe_head", "shovel_head",
    "hoe_head", "sword_head", "sword_binding", "spear_head", "spear_binding",
]
MOLDS = ["clay_mold", "terracotta_mold"]
errors = []

z = zipfile.ZipFile(JAR)
names = set(z.namelist())

version = json.loads(z.read("fabric.mod.json"))["version"]
print(f"jar version: {version}")
if version != "1.7.0":
    errors.append(f"fabric.mod.json version is {version}, expected 1.7.0")


def model_exists(model_id):
    ns, _, path = model_id.partition(":")
    return f"assets/{ns}/models/{path}.json" in names


# 1) item definitions
for mold in MOLDS:
    d = json.loads(z.read(f"assets/modular_dreams/items/{mold}.json"))["model"]
    if d.get("type") != "minecraft:select":
        errors.append(f"{mold}: item definition is not a select")
    if d.get("property") != "minecraft:component":
        errors.append(f"{mold}: property is not minecraft:component")
    if d.get("component") != "modular_dreams:mold_part":
        errors.append(f"{mold}: component is not modular_dreams:mold_part")
    whens = [c["when"] for c in d.get("cases", [])]
    if whens != SHAPES:
        errors.append(f"{mold}: case order/ids wrong: {whens}")
    if not d.get("fallback", {}).get("model", "").endswith(mold):
        errors.append(f"{mold}: fallback wrong")
    for case in d.get("cases", []):
        if not model_exists(case["model"]["model"]):
            errors.append(f"{mold}: missing case model {case['model']['model']}")
    if not model_exists(d["fallback"]["model"]):
        errors.append(f"{mold}: missing fallback model")
    print(f"item def {mold}: select/component/10 cases/fallback - all models present")

# 2) blockstates + 3) block model faces
for mold in MOLDS:
    bs = json.loads(z.read(f"assets/modular_dreams/blockstates/{mold}.json"))
    variants = bs["variants"]
    if len(variants) != 11:
        errors.append(f"{mold}: blockstate has {len(variants)} variants, expected 11")
    for key, variant in variants.items():
        if not model_exists(variant["model"]):
            errors.append(f"{mold}: blockstate variant {key} missing {variant['model']}")
    print(f"blockstate {mold}: 11 variants, all models present")

mold_models = sorted(
    n for n in names
    if n.startswith("assets/modular_dreams/models/block/")
    and any(n.endswith(f"{m}.json") or f"{m}_shaped_" in n for m in MOLDS)
)
checked = 0
bad = []
for n in mold_models:
    m = json.loads(z.read(n))
    for el in m.get("elements", []):
        for f, fd in el.get("faces", {}).items():
            if f in ("north", "south", "east", "west") and fd.get("cullface") == "down":
                bad.append(n)
    checked += 1
if bad:
    errors.append(f"bogus side cullface in: {bad}")
print(f"block models: {checked} checked, 0 bogus side cullfaces")

# 4) lang
lang = json.loads(z.read("assets/modular_dreams/lang/en_us.json"))
if "RE-SHAPE" not in lang.get("guide.modular_dreams.molds.2", ""):
    errors.append("lang molds.2 lacks re-shape text")
print(f"lang: {len(lang)} keys, re-shape text present")

# 5) carved textures
carved = [n for n in names if "top_shaped" in n and n.endswith(".png")]
if len(carved) != 20:
    errors.append(f"expected 20 carved top textures, found {len(carved)}")
print(f"carved top textures: {len(carved)}")

if errors:
    print("\nFAILURES:")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("\nBUILD 17 AUDIT: ALL GREEN")
