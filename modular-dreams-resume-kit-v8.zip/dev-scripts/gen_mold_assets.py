#!/usr/bin/env python3
"""Generates Build 12 assets: flat mold block textures + melting upgrade GUI.

Outputs (into src/main/resources/assets/modular_dreams/):
- textures/block/clay_mold_top.png       16x16, clay palette, darker rim ring
- textures/block/clay_mold_side.png      16x1 side strip
- textures/block/terracotta_mold_top.png 16x16
- textures/block/terracotta_mold_side.png 16x1
- textures/gui/melting_upgrade.png       176x166 vanilla-style container background
"""
from PIL import Image
import random
import os

ROOT = "/home/z/my-project/mod/modular-dreams/src/main/resources/assets/modular_dreams"
random.seed(20260928)


def clamp(v):
    return max(0, min(255, int(v)))


def noise_color(base, amount=5):
    return tuple(clamp(v + random.randint(-amount, amount)) for v in base)


def make_mold_top(path, base, rim):
    img = Image.new("RGBA", (16, 16))
    px = img.load()
    for x in range(16):
        for y in range(16):
            px[x, y] = noise_color(base) + (255,)
    # 1px darker rim around the edge -> reads as a mold tray
    for i in range(16):
        px[i, 0] = noise_color(rim, 3) + (255,)
        px[i, 15] = noise_color(rim, 3) + (255,)
        px[0, i] = noise_color(rim, 3) + (255,)
        px[15, i] = noise_color(rim, 3) + (255,)
    img.save(path)


def make_side(path, base):
    img = Image.new("RGBA", (16, 1))
    px = img.load()
    for x in range(16):
        px[x, 0] = noise_color(base, 4) + (255,)
    img.save(path)


def slot_well(img, x, y):
    """Vanilla-style 18x18 slot well (dark top/left, white bottom/right)."""
    px = img.load()
    for i in range(18):
        px[x + i, y] = (55, 55, 55, 255)
        px[x, y + i] = (55, 55, 55, 255)
        px[x + i, y + 17] = (255, 255, 255, 255)
        px[x + 17, y + i] = (255, 255, 255, 255)
    for dx in range(1, 17):
        for dy in range(1, 17):
            px[x + dx, y + dy] = (139, 139, 139, 255)


def make_gui(path):
    W, H = 176, 166
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    px = img.load()

    BODY = (198, 198, 198, 255)
    BORDER = (0, 0, 0, 255)
    HIGHLIGHT = (255, 255, 255, 255)
    SHADE = (85, 85, 85, 255)

    # panel with vanilla-style rounded corners
    for y in range(1, H - 1):
        for x in range(1, W - 1):
            px[x, y] = BODY
    for i in range(W):
        px[i, 0] = BORDER
        px[i, H - 1] = BORDER
    for j in range(H):
        px[0, j] = BORDER
        px[W - 1, j] = BORDER
    # corner cuts
    for cx, cy in ((1, 1), (W - 2, 1), (1, H - 2), (W - 2, H - 2)):
        px[cx, cy] = BORDER
    # top/left highlight + bottom/right shade (inner 1px)
    for x in range(1, W - 1):
        px[x, 1] = HIGHLIGHT
        px[x, H - 2] = SHADE
    for y in range(1, H - 1):
        px[1, y] = HIGHLIGHT
        px[W - 2, y] = SHADE

    # machine slots: output (part) top, mold bottom (menu coords 79/18 and 79/54)
    slot_well(img, 79, 18)
    slot_well(img, 79, 54)

    # upward arrow between the slots: the melted part rises out of the mold
    AX = 88  # arrow center x
    ARROW = (85, 85, 85, 255)
    # shaft
    for y in range(44, 52):
        for x in range(AX - 1, AX + 2):
            px[x, y] = ARROW
    # head
    for dy, half in enumerate((4, 3, 2, 1)):  # y=38..41 widening down
        for x in range(AX - half, AX + half + 1):
            px[x, 38 + dy] = ARROW

    # player inventory: 3x9 grid at y=84 + hotbar at y=142 (vanilla layout)
    for row in range(3):
        for col in range(9):
            slot_well(img, 8 + col * 18, 84 + row * 18)
    for col in range(9):
        slot_well(img, 8 + col * 18, 142)

    img.save(path)


def main():
    block_dir = os.path.join(ROOT, "textures", "block")
    gui_dir = os.path.join(ROOT, "textures", "gui")
    os.makedirs(block_dir, exist_ok=True)
    os.makedirs(gui_dir, exist_ok=True)

    CLAY = (164, 168, 184)
    CLAY_RIM = (134, 138, 154)
    CLAY_SIDE = (146, 150, 166)
    TERRA = (152, 94, 67)
    TERRA_RIM = (118, 70, 48)
    TERRA_SIDE = (136, 84, 60)

    make_mold_top(os.path.join(block_dir, "clay_mold_top.png"), CLAY, CLAY_RIM)
    make_side(os.path.join(block_dir, "clay_mold_side.png"), CLAY_SIDE)
    make_mold_top(os.path.join(block_dir, "terracotta_mold_top.png"), TERRA, TERRA_RIM)
    make_side(os.path.join(block_dir, "terracotta_mold_side.png"), TERRA_SIDE)
    make_gui(os.path.join(gui_dir, "melting_upgrade.png"))
    print("assets generated:")
    for name in ("clay_mold_top.png", "clay_mold_side.png", "terracotta_mold_top.png",
                 "terracotta_mold_side.png"):
        print("  textures/block/" + name)
    print("  textures/gui/melting_upgrade.png")


if __name__ == "__main__":
    main()
