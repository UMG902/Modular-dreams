#!/usr/bin/env bash
# Build 14 packaging: fresh deliverables into download/
set -euo pipefail

PROJ=/home/z/my-project/mod/modular-dreams
DL=/home/z/my-project/download
WORK=/home/z/my-project
BUILD_DIR=$WORK/work/pkg15

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/modular-dreams-src"

# 1) copy the built jars
cp "$PROJ/build/libs/modular-dreams-1.5.0.jar" "$BUILD_DIR/"
cp "$PROJ/build/libs/modular-dreams-1.5.0-sources.jar" "$BUILD_DIR/"

# 2) full readable source tree (main + client sources, build files, no build output)
cd "$PROJ"
rsync -a --exclude build --exclude .gradle --exclude run \
        src gradle.properties build.gradle settings.gradle \
        "$BUILD_DIR/modular-dreams-src/" 2>/dev/null || {
  # rsync missing -> plain copy fallback
  cp -r src "$BUILD_DIR/modular-dreams-src/"
  cp gradle.properties build.gradle settings.gradle "$BUILD_DIR/modular-dreams-src/" 2>/dev/null || true
}

# 3) notes + worklog
cp "$WORK/scripts/build15_notes.txt" "$BUILD_DIR/BUILD-15-NOTES.txt"
cp "$WORK/worklog.md" "$BUILD_DIR/worklog.md"

# 4) zip it all (fresh: remove any previous zip first)
cd "$BUILD_DIR"
rm -f "$DL/modular-dreams-ALL-IN-ONE.zip"
zip -qr "$DL/modular-dreams-ALL-IN-ONE.zip" .

# 5) bare jars + notes into download/ as well
cp "$BUILD_DIR/modular-dreams-1.5.0.jar" "$DL/"
cp "$BUILD_DIR/modular-dreams-1.5.0-sources.jar" "$DL/"
cp "$BUILD_DIR/BUILD-15-NOTES.txt" "$DL/"

# 6) drop stale 1.4.0 deliverables (fresh build supersedes them)
rm -f "$DL/modular-dreams-1.4.0.jar" "$DL/modular-dreams-1.4.0-sources.jar" "$DL/BUILD-14-NOTES.txt"

echo "--- packaged: ---"
ls -la "$DL"
python3 - <<'EOF'
import zipfile
z = zipfile.ZipFile('/home/z/my-project/download/modular-dreams-ALL-IN-ONE.zip')
tops = {}
for n in z.namelist():
    top = n.split('/')[0]
    tops[top] = tops.get(top, 0) + 1
for k, v in sorted(tops.items()):
    print(f"{v:5d}  {k}")
print("total:", len(z.namelist()))
EOF
