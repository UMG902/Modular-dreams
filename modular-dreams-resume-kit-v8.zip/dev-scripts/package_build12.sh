#!/usr/bin/env bash
# Build 12 packaging: deliver jars + ALL-IN-ONE zip to download/
set -e
SRC=/home/z/my-project/mod/modular-dreams
DL=/home/z/my-project/download
WORK=/home/z/my-project/work

# 1. fresh jars into download/
cp "$SRC/build/libs/modular-dreams-1.2.0.jar" "$DL/"
cp "$SRC/build/libs/modular-dreams-1.2.0-sources.jar" "$DL/"
rm -f "$DL/modular-dreams-1.1.0.jar" "$DL/modular-dreams-1.1.0-sources.jar"

# 2. ALL-IN-ONE zip: jars + full source tree + notes + worklog
cd "$SRC"
STAGE=$(mktemp -d)
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/modular-dreams-src"

# source tree without build artifacts
tar -C "$SRC" --exclude='./build' --exclude='./.gradle' --exclude='./run' \
    --exclude='./.git' -cf - . | tar -C "$STAGE/modular-dreams-src" -xf -

cp "$SRC/build/libs/modular-dreams-1.2.0.jar" "$STAGE/"
cp "$SRC/build/libs/modular-dreams-1.2.0-sources.jar" "$STAGE/"
cp "$WORK/BUILD-12-NOTES.txt" "$STAGE/"
cp /home/z/my-project/worklog.md "$STAGE/"

rm -f "$DL/modular-dreams-ALL-IN-ONE.zip"
cd "$STAGE" && zip -qr "$DL/modular-dreams-ALL-IN-ONE.zip" .

# 3. summary
ls -la "$DL"
unzip -l "$DL/modular-dreams-ALL-IN-ONE.zip" | tail -2
