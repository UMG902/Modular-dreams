#!/usr/bin/env python3
"""Build 18 asset audit - verifies the shipped jar:
  1. version 1.8.0 in fabric.mod.json
  2. ZERO blaze/breeze rod BINDING artifacts (item defs, recipes, lang keys)
     - rods are HANDLE-ONLY since build 18
  3. vibrant tint palette present in BOTH static tool defs (decimal RGB)
     and generated part defs (signed ARGB), old tints fully gone
  4. build-17 regressions: mold item defs keep the select/10-case carveout,
     all mold blockstate models still in the jar
"""
import json
import sys
import zipfile

JAR = "/home/z/my-project/modular-dreams/build/libs/modular-dreams-1.8.0.jar"

NEW_DEC = {"gold": 16766720, "copper": 16739642, "blaze_rod": 16747008, "breeze_rod": 5232127}
OLD_DEC = {15170646, 16375371, 16625711, 9418440}
OLD_ARGB = {-1606570, -401845, -151505, -7358776}  # signed 0xFFE77C56 etc.
NEW_ARGB = {"gold_handle": -10496, "copper_pickaxe_head": -37574,
            "blaze_rod_handle": -30208, "breeze_rod_handle": -11545089}

fails = []
jar = zipfile.ZipFile(JAR)
names = jar.namelist()

# 1. version
ver = json.loads(jar.read("fabric.mod.json"))["version"]
if ver != "1.8.0":
    fails.append(f"version is {ver}, expected 1.8.0")

# 2. rod bindings eradicated
rb = [n for n in names if "rod_binding" in n]
if rb:
    fails.append(f"rod_binding entries in jar: {rb}")
lang = json.loads(jar.read("assets/modular_dreams/lang/en_us.json"))
lb = [k for k in lang if "rod_binding" in k]
if lb:
    fails.append(f"rod_binding lang keys: {lb}")
for rod in ("blaze_rod", "breeze_rod"):
    if f"item.modular_dreams.{rod}_handle" not in lang:
        fails.append(f"missing lang key for {rod}_handle")

# 3. tints
tools = ["modular_pickaxe", "modular_axe", "modular_shovel", "modular_hoe", "modular_sword", "modular_spear"]
for t in tools:
    d = json.loads(jar.read(f"assets/modular_dreams/items/{t}.json"))
    for layer in d["model"]["layers"]:
        for mkey, variant in layer.get("variants", {}).items():
            val = variant.get("tints", [{}])[0].get("value")
            if val in OLD_DEC:
                fails.append(f"{t}: old tint {val} in variant {mkey}")
            if mkey in NEW_DEC and val != NEW_DEC[mkey]:
                fails.append(f"{t}: {mkey} tint {val}, expected {NEW_DEC[mkey]}")
            if mkey in ("blaze_rod", "breeze_rod") and layer.get("part") != "handle":
                fails.append(f"{t}: rod variant in non-handle layer '{layer.get('part')}'")
for part, argb in NEW_ARGB.items():
    d = json.loads(jar.read(f"assets/modular_dreams/items/{part}.json"))
    val = d["model"]["tints"][0]["value"]
    if val != argb:
        fails.append(f"generated {part}: tint {val}, expected {argb}")
gen_items = [n for n in names if n.startswith("assets/modular_dreams/items/") and n.endswith(".json")]
for n in gen_items:
    d = json.loads(jar.read(n))
    for tint in d.get("model", {}).get("tints", []):
        if tint.get("value") in OLD_ARGB:
            fails.append(f"{n}: old ARGB tint {tint['value']}")

# 4. build-17 regressions
for mold in ("clay_mold", "terracotta_mold"):
    d = json.loads(jar.read(f"assets/modular_dreams/items/{mold}.json"))
    if d["model"].get("type") != "minecraft:select" or len(d["model"].get("cases", [])) != 10:
        fails.append(f"{mold}: item def lost its select/10-case structure")
models = [n for n in names if n.startswith("assets/modular_dreams/models/")]
if len(models) < 20:
    fails.append(f"only {len(models)} models in jar - mold models missing?")
bad_cull = sum(jar.read(n).decode().count('"cullface": "down"') for n in models if n.endswith(".json") and "mold" in n)
if bad_cull > 22:
    fails.append(f"unexpected cullface down count in mold models: {bad_cull}")

if fails:
    print("AUDIT FAILED:")
    for f in fails:
        print(" -", f)
    sys.exit(1)
print(f"AUDIT PASSED: {len(names)} entries, v1.8.0, rods handle-only, vibrant palette live, molds intact")
