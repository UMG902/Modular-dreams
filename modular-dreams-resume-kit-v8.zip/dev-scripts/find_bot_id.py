#!/usr/bin/env python3
"""Read-only inspect of the gateway sqlite DB to find this chat's bot id."""
import sqlite3, json, sys

DB = "file:/home/z/my-project/db/custom.db?mode=ro"
CHAT_ID = "a333752b-0023-43b7-a5cd-3ea9b981c942"
SESSION_ID = "web-a2841a87-963a-441d-9b47-48470a4d2686"

con = sqlite3.connect(DB, uri=True, timeout=5)
con.row_factory = sqlite3.Row
cur = con.cursor()

tables = [r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
print("tables:", tables)

for t in tables:
    cols = [c[1] for c in cur.execute(f"PRAGMA table_info({t})")]
    print(f"\n== {t}: {cols}")
    # find rows referencing this chat or session, but only dump likely-relevant tables
    low = [c.lower() for c in cols]
    interesting = any(k in " ".join(low) for k in ("bot", "preview", "chat", "session", "url", "domain"))
    if not interesting:
        continue
    try:
        n = cur.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        print(f"   rows: {n}")
        for k, v in (("chat_id", CHAT_ID), ("session_id", SESSION_ID)):
            if k in low:
                hits = cur.execute(f"SELECT * FROM {t} WHERE {k} = ? LIMIT 3", (v,)).fetchall()
                for h in hits:
                    print("   MATCH:", json.dumps({c: h[c] for c in h.keys()}, default=str)[:1500])
    except Exception as e:
        print("   query error:", e)
con.close()
