#!/usr/bin/env bash
# Build 16 redelivery: fresh-timestamp copies of the already-built v1.6.0 deliverables.
# The mod jar is NOT rebuilt - it was verified intact (483 entries, fabric.mod.json 1.6.0).
set -euo pipefail

PROJ=/home/z/my-project/mod/modular-dreams
DL=/home/z/my-project/download
WORK=/home/z/my-project
BUILD_DIR=$WORK/work/pkg16r

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/modular-dreams-src"

# 1) copy the built jars (fresh mtime)
cp "$PROJ/build/libs/modular-dreams-1.6.0.jar" "$BUILD_DIR/"
cp "$PROJ/build/libs/modular-dreams-1.6.0-sources.jar" "$BUILD_DIR/"

# 2) full readable source tree
cd "$PROJ"
rsync -a --exclude build --exclude .gradle --exclude run \
        src gradle.properties build.gradle settings.gradle \
        "$BUILD_DIR/modular-dreams-src/" 2>/dev/null || {
  cp -r src "$BUILD_DIR/modular-dreams-src/"
  cp gradle.properties build.gradle settings.gradle "$BUILD_DIR/modular-dreams-src/" 2>/dev/null || true
}

# 3) notes + updated worklog
cp "$WORK/scripts/build16_notes.txt" "$BUILD_DIR/BUILD-16-NOTES.txt"
cp "$WORK/worklog.md" "$BUILD_DIR/worklog.md"

# 4) rebuild the zip from scratch
cd "$BUILD_DIR"
rm -f "$DL/modular-dreams-ALL-IN-ONE.zip"
zip -qr "$DL/modular-dreams-ALL-IN-ONE.zip" .

# 5) bare jars + notes into download/ (fresh mtime)
cp "$BUILD_DIR/modular-dreams-1.6.0.jar" "$DL/"
cp "$BUILD_DIR/modular-dreams-1.6.0-sources.jar" "$DL/"
cp "$BUILD_DIR/BUILD-16-NOTES.txt" "$DL/"

# 6) sanity: no stale versions, no xlsx/md strays in download/
rm -f "$DL"/modular-dreams-1.5.0*.jar "$DL"/BUILD-15-NOTES.txt

echo "--- redelivered: ---"
python3 - <<'EOF'
import zipfile, os, hashlib, json
dl = '/home/z/my-project/download'
for f in sorted(os.listdir(dl)):
    p = os.path.join(dl, f)
    h = hashlib.md5(open(p, 'rb').read()).hexdigest()[:10]
    import time
    print(f"{os.path.getsize(p):>9,} bytes  md5:{h}  {time.strftime('%H:%M:%S', time.localtime(os.path.getmtime(p)))}  {f}")
z = zipfile.ZipFile(os.path.join(dl, 'modular-dreams-1.6.0.jar'))
fm = json.loads(z.read('fabric.mod.json'))
print('jar entries:', len(z.namelist()), '| fabric.mod.json version:', fm['version'])
za = zipfile.ZipFile(os.path.join(dl, 'modular-dreams-ALL-IN-ONE.zip'))
print('ALL-IN-ONE entries:', len(za.namelist()))
EOF
