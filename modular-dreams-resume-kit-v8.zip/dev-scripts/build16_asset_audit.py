#!/usr/bin/env python3
"""Build 16 jar audit: mold cutouts, universal binding, melting furnace GUI, lang."""
import json
import io
import sys
import zipfile
from PIL import Image

JAR = '/home/z/my-project/mod/modular-dreams/build/libs/modular-dreams-1.6.0.jar'
errors = []
oks = []

def check(cond, msg):
    (oks if cond else errors).append(msg)

z = zipfile.ZipFile(JAR)
names = set(z.namelist())
check(len(names) > 400, f'jar has {len(names)} entries')

# ---------------------------------------------------------- fabric.mod.json
fmj = json.loads(z.read('fabric.mod.json'))
check(fmj['version'] == '1.6.0', f"fabric.mod.json version = {fmj['version']}")

# ---------------------------------------------------------- mold blockstates + models
for mold in ('clay_mold', 'terracotta_mold'):
    bs = json.loads(z.read(f'assets/modular_dreams/blockstates/{mold}.json'))
    variants = bs['variants']
    check('shape=none' in variants, f'{mold} blockstate has shape=none')
    shaped = [k for k in variants if k.startswith('shape=') and k != 'shape=none']
    check(len(shaped) == 10, f'{mold} blockstate has 10 shaped variants (got {len(shaped)})')
    for key, ref in variants.items():
        ns, path = ref['model'].split(':')
        model_path = f'assets/{ns}/models/{path}.json'
        if model_path not in names:
            errors.append(f'{mold} variant {key}: model {ref["model"]} MISSING')
    # shaped models: cutout render type + shaped top texture present with real holes
    for part in ('pickaxe_head', 'handle', 'binding', 'sword_binding'):
        mp = f'assets/modular_dreams/models/block/{mold}_shaped_{part}.json'
        if mp not in names:
            errors.append(f'model {mp} MISSING'); continue
        m = json.loads(z.read(mp))
        check(m.get('render_type') == 'minecraft:cutout', f'{mold}_shaped_{part}: render_type cutout')
        top = m['textures']['top']
        ns, tpath = top.split(':')
        tp = f'assets/{ns}/textures/{tpath}.png'
        if tp not in names:
            errors.append(f'texture {tp} MISSING'); continue
        img = Image.open(io.BytesIO(z.read(tp))).convert('RGBA')
        alpha = img.getchannel('A')
        transparent = sum(alpha.histogram()[0:8])
        check(transparent > 5, f'{tp}: {transparent} transparent px (carved hole)')

# ---------------------------------------------------------- universal binding parts
for mat in ('wood', 'stone', 'flint', 'leather', 'bone', 'vine', 'string', 'slime', 'copper', 'iron', 'gold'):
    if f'assets/modular_dreams/items/{mat}_binding.json' not in names:
        errors.append(f'item def {mat}_binding.json MISSING')
for tool in ('pickaxe', 'axe', 'shovel', 'hoe'):
    for mat in ('iron', 'wood', 'gold'):
        stale = f'assets/modular_dreams/items/{mat}_{tool}_binding.json'
        check(stale not in names, f'stale {stale} absent')
for mat in ('wood', 'stone'):
    check(f'data/modular_dreams/recipe/parts/{mat}_binding.json' in names,
          f'part builder recipe {mat}_binding present')
    check(f'data/modular_dreams/recipe/parts/{mat}_pickaxe_binding.json' not in names,
          f'stale recipe {mat}_pickaxe_binding absent')
# metals must NOT have part builder recipes (they melt instead)
check(f'data/modular_dreams/recipe/parts/iron_binding.json' not in names,
      'iron_binding correctly absent from part builder recipes')

# ---------------------------------------------------------- tool defs: layer part vs model
for tool, expected_model in (('pickaxe', 'pickaxe_binding'), ('axe', 'axe_binding'),
                             ('shovel', 'shovel_binding'), ('hoe', 'hoe_binding')):
    d = json.loads(z.read(f'assets/modular_dreams/items/modular_{tool}.json'))
    layers = {l['part']: l for l in d['model']['layers']}
    check('binding' in layers, f'modular_{tool}: binding layer uses universal part')
    bind_layer = layers.get('binding')
    if bind_layer:
        models = {v['model'] for v in bind_layer['variants'].values()}
        check(models == {f'modular_dreams:{expected_model}'},
              f'modular_{tool}: binding layer renders {expected_model} model')
sword = json.loads(z.read('assets/modular_dreams/items/modular_sword.json'))
slayers = {l['part']: l for l in sword['model']['layers']}
check('sword_binding' in slayers, 'modular_sword: dedicated sword_binding layer kept')
spear = json.loads(z.read('assets/modular_dreams/items/modular_spear.json'))
players = {l['part']: l for l in spear['model']['layers']}
check('spear_binding' in players, 'modular_spear: dedicated spear_binding layer kept')

# ---------------------------------------------------------- lang
lang = json.loads(z.read('assets/modular_dreams/lang/en_us.json'))
check(lang.get('part.modular_dreams.sword_binding') == 'Sword Guard', 'lang: Sword Guard part name')
check(lang.get('item.modular_dreams.iron_sword_binding') == 'Iron Sword Guard', 'lang: Iron Sword Guard item')
check(lang.get('part.modular_dreams.binding') == 'Binding', 'lang: universal Binding part name')
check(lang.get('item.modular_dreams.iron_binding') == 'Iron Binding', 'lang: Iron Binding item')
stale_lang = [k for k in lang if 'pickaxe_binding' in k or 'axe_binding' in k
              or 'shovel_binding' in k or 'hoe_binding' in k]
check(not stale_lang, f'lang: no stale per-tool binding keys ({stale_lang[:3]})')

# ---------------------------------------------------------- classes
check('com/modulardreams/part/MoldShape.class' in names, 'MoldShape class present')
check('com/modulardreams/client/render/MoldImprintRenderer.class' not in names,
      'MoldImprintRenderer REMOVED from jar')
mb = z.read('com/modulardreams/block/MoldBlock.class')
check(b'shape' in mb and b'MoldShape' in mb, 'MoldBlock uses shape property + MoldShape')

# ---------------------------------------------------------- texture sanity: item textures
check('assets/modular_dreams/textures/item/binding.png' in names, 'textures/item/binding.png present')

print(f'PASS: {len(oks)} checks')
for e in errors:
    print('FAIL:', e)
sys.exit(1 if errors else 0)
