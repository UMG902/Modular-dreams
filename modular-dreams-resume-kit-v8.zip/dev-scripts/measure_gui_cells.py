#!/usr/bin/env python3
"""Precisely locate cell borders in the GUI textures.
Vanilla convention: 18x18 cell art with 1px dark (#373737) top/left border,
1px white (#FFFFFF) bottom/right border; the menu slot coord = art top-left + (1,1)."""
from PIL import Image

def runs(img, fixed, axis, x0, x1, y0=None, y1=None, color=(55, 55, 55)):
    """Print horizontal/vertical runs of a color inside a region."""
    px = img.load()
    segs = []
    cur = None
    if axis == "row":     # scan along x at y=fixed
        rng = range(x0, x1)
        def get(i):
            return px[i, fixed]
    else:                 # scan along y at x=fixed
        rng = range(y0, y1)
        def get(i):
            return px[fixed, i]
    for i in rng:
        c = get(i)
        if c[:3] == color:
            if cur is None:
                cur = [i, i]
            else:
                cur[1] = i
        else:
            if cur is not None:
                segs.append(tuple(cur))
                cur = None
    if cur is not None:
        segs.append(tuple(cur))
    return [s for s in segs if s[1] - s[0] >= 3]

def cell_scan(path, label):
    img = Image.open(path).convert("RGBA")
    print(f"== {label} {img.size}")
    px = img.load()
    # find all dark border pixels and cluster into cells:
    # a cell top-left corner (x,y): px[x,y]=dark, px[x,y+17]=white, px[x+17,y]=white
    corners = []
    w, h = img.size
    for y in range(h - 18):
        for x in range(w - 18):
            if px[x, y][:3] == (55, 55, 55) and px[x + 17, y + 17][:3] == (255, 255, 255) \
               and px[x, y + 17][:3] == (255, 255, 255) and px[x + 17, y][:3] == (255, 255, 255):
                corners.append((x, y))
    # cluster corners within 2px
    clusters = []
    for c in corners:
        for cl in clusters:
            if abs(cl[0][0] - c[0]) <= 2 and abs(cl[0][1] - c[1]) <= 2:
                cl.append(c)
                break
        else:
            clusters.append([c])
    for cl in clusters:
        xs = sum(p[0] for p in cl) / len(cl)
        ys = sum(p[1] for p in cl) / len(cl)
        print(f"  cell top-left ~({xs:.1f},{ys:.1f}) -> slot should be ({round(xs)+1},{round(ys)+1}) [{len(cl)} px]")

A = "/home/z/my-project/mod/modular-dreams/src/main/resources/assets/modular_dreams/textures/gui/container/assembly_table.png"
M = "/home/z/my-project/mod/modular-dreams/src/main/resources/assets/modular_dreams/textures/gui/melting_upgrade.png"
cell_scan(A, "assembly_table.png")
cell_scan(M, "melting_upgrade.png")

# melting upgrade: grid rows in the inventory area
img = Image.open(M).convert("RGBA")
print("\nmelting_upgrade inventory grid horizontal dark lines (y: run):")
px = img.load()
for y in range(75, 166):
    seg = runs(img, y, "row", 4, 172)
    if seg and any(b - a > 100 for a, b in seg):
        print(f"  y={y}: {seg}")

print("\nassembly_table.png dark pixel bounding boxes by region:")
img = Image.open(A).convert("RGBA")
px = img.load()
# left column cells
xs, xe, ys, ye = 60, 170, 10, 100
darks = [(x, y) for y in range(ys, ye) for x in range(xs, xe) if px[x, y][:3] == (55, 55, 55)]
if darks:
    print(f"  result area darks x:{min(p[0] for p in darks)}..{max(p[0] for p in darks)} "
          f"y:{min(p[1] for p in darks)}..{max(p[1] for p in darks)}")
xs, xe, ys, ye = 0, 60, 10, 100
darks = [(x, y) for y in range(ys, ye) for x in range(xs, xe) if px[x, y][:3] == (55, 55, 55)]
if darks:
    print(f"  input area darks  x:{min(p[0] for p in darks)}..{max(p[0] for p in darks)} "
          f"y:{min(p[1] for p in darks)}..{max(p[1] for p in darks)}")
