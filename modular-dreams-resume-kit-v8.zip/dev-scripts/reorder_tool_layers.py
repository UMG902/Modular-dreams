#!/usr/bin/env python3
"""Build 11: reorder modular tool render layers.

Old order (datagen-era): handle, binding, head  -> head rendered on top.
New order per user spec: handle (lowest), head (middle), binding (on top).
"""
import json
import glob
import os

ITEMS_DIR = "/home/z/my-project/mod/modular-dreams/src/main/resources/assets/modular_dreams/items"

for path in sorted(glob.glob(os.path.join(ITEMS_DIR, "modular_*.json"))):
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)

    layers = data.get("model", {}).get("layers")
    if not layers:
        print(f"SKIP (no layers): {os.path.basename(path)}")
        continue

    tool = os.path.basename(path).replace("modular_", "").replace(".json", "")
    binding = f"{tool}_binding"
    head = f"{tool}_head"
    handle = f"{tool}_handle"

    by_part = {layer["part"]: layer for layer in layers}
    missing = [p for p in (handle, head, binding) if p not in by_part]
    if missing:
        print(f"SKIP (missing {missing}): {os.path.basename(path)}")
        continue

    data["model"]["layers"] = [by_part[handle], by_part[head], by_part[binding]]

    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=1, ensure_ascii=False)
        fh.write("\n")

    print(f"REORDERED {os.path.basename(path)}: {[l['part'] for l in data['model']['layers']]}")

print("done")
