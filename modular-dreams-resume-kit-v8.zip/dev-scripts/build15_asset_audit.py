#!/usr/bin/env python3
"""Build 15 asset audit: all prior checks plus the build 15 round
(GUI texture/menu alignment, universal-handle-only assembly, sword/spear
render-only handle shapes, block item names, carved mold imprint)."""
import io
import json
import sys
import zipfile

from PIL import Image

JAR = "/home/z/my-project/mod/modular-dreams/build/libs/modular-dreams-1.5.0.jar"

zf = zipfile.ZipFile(JAR)
names = set(zf.namelist())
missing = []
errors = []

json_files = [n for n in names if n.endswith(".json")]

for name in json_files:
    try:
        text = zf.read(name).decode("utf-8")
        data = json.loads(text)
    except Exception:
        continue

    if "/items/" in name:
        def walk(node):
            if isinstance(node, dict):
                if "model" in node and isinstance(node["model"], str):
                    model = node["model"]
                    if model.startswith(("minecraft:", "modular_dreams:")):
                        ns, p = model.split(":", 1)
                        target = f"assets/{ns}/models/{p}.json"
                        if target not in names:
                            missing.append((name, model))
                for v in node.values():
                    walk(v)
            elif isinstance(node, list):
                for v in node:
                    walk(v)
        walk(data)

    if "/blockstates/" in name:
        def walk_bs(node):
            if isinstance(node, dict):
                if "model" in node and isinstance(node["model"], str):
                    model = node["model"]
                    if model.startswith("modular_dreams:"):
                        ns, p = model.split(":", 1)
                        target = f"assets/{ns}/models/{p}.json"
                        if target not in names:
                            missing.append((name, model))
                for v in node.values():
                    walk_bs(v)
            elif isinstance(node, list):
                for v in node:
                    walk_bs(v)
        walk_bs(data)

    if "/models/" in name and isinstance(data, dict):
        for tex in data.get("textures", {}).values():
            if isinstance(tex, str) and tex.startswith("modular_dreams:"):
                ns, p = tex.split(":", 1)
                target = f"assets/{ns}/textures/{p}.png"
                if target not in names:
                    missing.append((name, tex))

print(f"jar entries: {len(names)}")
print(f"missing references: {len(missing)}")
for src, ref in missing[:20]:
    print(f"  MISSING {ref}   (in {src})")


def load(path):
    return json.loads(zf.read(path).decode("utf-8"))


# --- prior-build checks (abbreviated but still enforced) ---

fmf = load("fabric.mod.json")
if fmf.get("version") != "1.5.0":
    errors.append(f"fabric.mod.json version is {fmf.get('version')}, expected 1.5.0")

mace_strings = ["modular_mace", "mace_head", "mace_binding", "mace_handle"]
for name in json_files:
    try:
        text = zf.read(name).decode("utf-8")
    except Exception:
        continue
    for s in mace_strings:
        if s in text:
            errors.append(f"stale mace reference '{s}' in {name}")

lang = load("assets/modular_dreams/lang/en_us.json")
for key in ("guide.modular_dreams.book.page", "guide.modular_dreams.book.flow.1",
            "container.modular_dreams.melting_upgrade"):
    if key not in lang:
        errors.append(f"lang missing {key}")

# build 14: terracotta shaping guard + shaped-only baking
mb = zf.read("com/modulardreams/block/MoldBlock.class")
if b"TERRACOTTA_MOLD" not in mb:
    errors.append("MoldBlock.class terracotta guard missing")
mr = zf.read("com/modulardreams/recipe/MoldBakingRecipe.class")
if b"MOLD_PART" not in mr:
    errors.append("MoldBakingRecipe.class matches guard missing")

# ---------------------------------------------------------------- build 15

# 1. block item names: item.* keys for every placeable block
for block in ("part_builder", "assembly_table", "clay_mold", "terracotta_mold",
              "melting_upgrade"):
    if f"item.modular_dreams.{block}" not in lang:
        errors.append(f"lang missing item.modular_dreams.{block}")

# 2. sword/spear handle PARTS removed everywhere
for stale in ("part.modular_dreams.sword_handle", "part.modular_dreams.spear_handle",
              "item.modular_dreams.iron_sword_handle", "item.modular_dreams.wood_spear_handle"):
    if stale in lang:
        errors.append(f"stale lang key {stale}")
for stale in ("iron_sword_handle", "wood_spear_handle"):
    if f"assets/modular_dreams/items/{stale}.json" in names:
        errors.append(f"stale part item definition {stale}")
parts_dir = "data/modular_dreams/recipe/parts/"
stale_recipes = [n for n in names if n.startswith(parts_dir)
                 and ("sword_handle" in n or "spear_handle" in n)]
if stale_recipes:
    errors.append(f"stale handle recipes: {stale_recipes[:3]}")

# 3. render-only handle models exist; sword/spear defs use the universal handle
for model in ("sword_handle", "spear_handle"):
    if f"assets/modular_dreams/models/{model}.json" not in names:
        errors.append(f"missing render-only model {model}")
    if f"assets/modular_dreams/textures/item/{model}.png" not in names:
        errors.append(f"missing render-only texture {model}")
for tool, shape in (("sword", "sword_handle"), ("spear", "spear_handle")):
    d = load(f"assets/modular_dreams/items/modular_{tool}.json")
    layers = d["model"]["layers"]
    if layers[0]["part"] != "handle":
        errors.append(f"{tool} handle layer part is {layers[0]['part']}, expected 'handle'")
    variant_models = {v["model"] for v in layers[0]["variants"].values()}
    if variant_models != {f"modular_dreams:{shape}"}:
        errors.append(f"{tool} handle layer renders {variant_models}, expected {shape}")
    # tool layer order: universal handle -> head -> binding
    if [l["part"] for l in layers] != ["handle", f"{tool}_head", f"{tool}_binding"]:
        errors.append(f"{tool} layer order wrong")

# 4. GUI textures: slot cell art aligned with menu slots (art = slot - (1,1))
def cells(png):
    img = Image.open(io.BytesIO(zf.read(png))).convert("RGBA")
    px = img.load()
    found = set()
    for y in range(img.height - 18):
        for x in range(img.width - 18):
            if px[x, y][:3] == (55, 55, 55) and px[x + 1, y][:3] == (55, 55, 55) \
               and px[x, y + 1][:3] == (55, 55, 55) and px[x + 17, y + 17][:3] == (255, 255, 255):
                found.add((x, y))
    return found

at_cells = cells("assets/modular_dreams/textures/gui/container/assembly_table.png")
for art in ((43, 17), (43, 41), (43, 65), (133, 41)):      # slots (44,18/42/66),(134,42)
    if art not in at_cells:
        errors.append(f"assembly_table.png missing cell art at {art}")
mu_cells = cells("assets/modular_dreams/textures/gui/melting_upgrade.png")
for art in ((78, 17), (78, 53)):                            # slots (79,18),(79,54)
    if art not in mu_cells:
        errors.append(f"melting_upgrade.png missing cell art at {art}")
# player inventory section present in BOTH (art rows y=83 + hotbar 141)
for png, found in (("assembly_table", at_cells), ("melting_upgrade", mu_cells)):
    if (7, 83) not in found or (7, 141) not in found:
        errors.append(f"{png}.png missing player inventory cell art")

# 5. carved imprint: renderer has the two-quad method
mi = zf.read("com/modulardreams/client/render/MoldImprintRenderer.class")
if b"quad" not in mi or b"WALL_LIFT" not in mi:
    errors.append("MoldImprintRenderer.class missing carved-imprint quads")

# 6. melting furnace mold preview: the constant lives on the menu class
# (compile-time ints are inlined at use sites, so checking the screen class
#  for the field name would always fail)
mf = zf.read("com/modulardreams/menu/MeltingFurnaceMenu.class")
if b"MOLD_PREVIEW_X" not in mf:
    errors.append("MeltingFurnaceMenu.class missing MOLD_PREVIEW_X field")

print(f"build 15 checks: {len(errors)} errors")
for e in errors:
    print(f"  ERROR {e}")

sys.exit(1 if (missing or errors) else 0)
