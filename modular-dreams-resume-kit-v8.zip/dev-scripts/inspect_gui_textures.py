#!/usr/bin/env python3
"""Analyze the mod GUI textures: find slot cells (vanilla-style bevel boxes)
and report their top-left corners, plus general content stats."""
from PIL import Image

def slots(path):
    img = Image.open(path).convert("RGBA")
    w, h = img.size
    px = img.load()
    # vanilla slot cell: border #373737 top/left, #FFFFFF bottom/right,
    # inner #8B8B8B. Detect the top-left dark corner pixel pattern:
    # pixel(x,y)=#373737 and pixel(x+17,y)=#FFFFFF-ish and pixel(x,y+17)=#FFFFFF-ish
    found = []
    for y in range(h - 17):
        for x in range(w - 17):
            c = px[x, y]
            if c[:3] == (55, 55, 55):  # #373737
                r = px[x + 17, y + 17]
                r2 = px[x + 16, y + 17]
                r3 = px[x + 17, y + 16]
                if r[:3] == (255, 255, 255) or r2[:3] == (255, 255, 255) or r3[:3] == (255, 255, 255):
                    # inner sample
                    inn = px[x + 8, y + 8]
                    found.append((x, y, inn[:3]))
    return img.size, found

for path in [
    "/home/z/my-project/mod/modular-dreams/src/main/resources/assets/modular_dreams/textures/gui/container/assembly_table.png",
    "/home/z/my-project/mod/modular-dreams/src/main/resources/assets/modular_dreams/textures/gui/melting_upgrade.png",
]:
    size, found = slots(path)
    print(f"\n{path.split('/')[-1]} size={size}")
    # cluster found corners (unique x,y)
    uniq = sorted(set((x, y) for x, y, _ in found))
    print(f"slot-cell candidates ({len(uniq)}):")
    for x, y in uniq:
        print(f"  ({x},{y})")
