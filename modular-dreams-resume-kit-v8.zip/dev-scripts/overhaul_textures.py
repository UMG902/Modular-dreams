#!/usr/bin/env python3
"""Modular Dreams overhaul step 1 - texture pipeline.

1. Extracts TiC 3.12 grayscale part textures (MIT licensed, Tinkers' Construct)
   for the 21 part shapes and renames them to our scheme.
2. Generates grayscale armor part textures (plating/attachment/lining x 4).
3. Draws block textures (assembly_table, clay_mold, melting_upgrade).
4. Draws mold item icons and the assembly table GUI.
5. Removes obsolete per-material textures from the old build.
"""
import os, shutil, glob
from PIL import Image, ImageDraw

TIC = "/home/z/my-project/work/tic-assets/assets/tconstruct/textures/item/tool"
RES = "/home/z/my-project/mod/modular-dreams/src/main/resources/assets/modular_dreams/textures"
ITEM = f"{RES}/item"
BLOCK = f"{RES}/block"
GUI = f"{RES}/gui/container"

os.makedirs(ITEM, exist_ok=True)
os.makedirs(BLOCK, exist_ok=True)
os.makedirs(GUI, exist_ok=True)

# ---------------------------------------------------------------- 1. part textures
# target name -> (source file, grayscale L mode)
PARTS = {
    "pickaxe_head": "pickaxe/head.png", "pickaxe_binding": "pickaxe/binding.png",
    "pickaxe_handle": "pickaxe/handle.png",
    "axe_head": "hand_axe/head.png", "axe_binding": "hand_axe/binding.png",
    "axe_handle": "pickaxe/handle.png",
    "shovel_head": "excavator/head.png", "shovel_binding": "excavator/binding.png",
    "shovel_handle": "excavator/handle.png",
    "hoe_head": "kama/head.png", "hoe_binding": "kama/binding.png",
    "hoe_handle": "scythe/handle.png",
    "sword_head": "sword/blade.png", "sword_binding": "sword/guard.png",
    "sword_handle": "sword/handle.png",
    "mace_head": "sledge_hammer/head.png", "mace_binding": "sledge_hammer/back.png",
    "mace_handle": "sledge_hammer/handle.png",
    "spear_head": "javelin/head.png", "spear_binding": "javelin/guard.png",
    "spear_handle": "javelin/handle.png",
}
def to_grayscale_alpha(path):
    """Convert RGBA tinted TiC texture to grayscale RGBA (alpha kept)."""
    im = Image.open(path).convert("RGBA")
    px = im.load()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = px[x, y]
            lum = int(0.299 * r + 0.587 * g + 0.114 * b)
            px[x, y] = (lum, lum, lum, a)
    return im

for target, src in PARTS.items():
    src_path = f"{TIC}/{src}"
    im = Image.open(src_path)
    if im.mode == "L":
        # TiC generator texture: L=0 transparent, L>0 shading intensity.
        # -> RGBA with binary shape mask + grayscale shading (tint-multiplies cleanly)
        luma = im.load()
        out = Image.new("RGBA", im.size, (0, 0, 0, 0))
        px = out.load()
        for y in range(im.height):
            for x in range(im.width):
                v = luma[x, y]
                if v > 0:
                    px[x, y] = (v, v, v, 255)
        out.save(f"{ITEM}/{target}.png")
    else:
        to_grayscale_alpha(src_path).save(f"{ITEM}/{target}.png")
print(f"extracted {len(PARTS)} part textures")

# ---------------------------------------------------------------- 2. armor part textures
pieces = ["helmet", "chestplate", "leggings", "boots"]
armor_src = f"{TIC}/armor/plate"
for piece in pieces:
    plating = to_grayscale_alpha(f"{armor_src}/{piece}/plating.png")
    plating.save(f"{ITEM}/plating_{piece}.png")
    # attachment: inner outline of the plating silhouette
    att = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px_src = plating.load()
    px_att = att.load()
    for y in range(16):
        for x in range(16):
            r, g, b, a = px_src[x, y]
            if a > 0:
                neighbours = []
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < 16 and 0 <= ny < 16:
                        neighbours.append(px_src[nx, ny][3])
                    else:
                        neighbours.append(0)
                if min(neighbours) > 0:  # fully interior pixel -> attachment
                    px_att[x, y] = (140, 140, 140, a)
    att.save(f"{ITEM}/attachment_{piece}.png")
    # lining: soft padded core (bright interior)
    lining = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px_lin = lining.load()
    for y in range(16):
        for x in range(16):
            r, g, b, a = px_src[x, y]
            if a > 0 and min([px_src[max(0, x-1), y][3], px_src[min(15, x+1), y][3],
                              px_src[x, max(0, y-1)][3], px_src[x, min(15, y+1)][3]]) > 0:
                px_lin[x, y] = (225, 225, 225, a)
    lining.save(f"{ITEM}/lining_{piece}.png")
print(f"generated 12 armor part textures")

# ---------------------------------------------------------------- 3. block textures
def base_panel(size, top_rgb, side_rgb, accent_rgb):
    im = Image.new("RGBA", (size, size), side_rgb + (255,))
    d = ImageDraw.Draw(im)
    for i in range(0, size, 4):
        d.line([(i, 0), (i, size)], fill=tuple(max(0, c - 12) for c in side_rgb) + (255,))
    return im

# assembly table: warm wood with metal bands (top carries 3 slot squares)
wood_top, wood_side, wood_dark = (146, 106, 60), (122, 90, 50), (96, 70, 40)
t = Image.new("RGBA", (16, 16), wood_top + (255,))
d = ImageDraw.Draw(t)
d.rectangle([0, 0, 15, 15], outline=wood_dark, fill=None)
for i in range(3):
    d.rectangle([2 + i * 5, 2, 5 + i * 5, 13], outline=wood_dark)
    d.rectangle([3 + i * 5, 3, 4 + i * 5, 12], fill=(120, 120, 128, 255))
t.save(f"{BLOCK}/assembly_table_top.png")

s = Image.new("RGBA", (16, 16), wood_side + (255,))
d = ImageDraw.Draw(s)
for y in range(16):
    if y in (3, 11):
        d.line([(0, y), (15, y)], fill=wood_dark)
d.rectangle([2, 5, 13, 9], outline=wood_dark)
s.save(f"{BLOCK}/assembly_table_side.png")

Image.new("RGBA", (16, 16), wood_dark + (255,)).save(f"{BLOCK}/assembly_table_bottom.png")

# clay mold: raw clay with a bowl hollow
c = Image.new("RGBA", (16, 16), (152, 160, 168, 255))
d = ImageDraw.Draw(c)
d.rectangle([0, 0, 15, 15], outline=(120, 128, 136, 255))
d.ellipse([3, 5, 12, 12], fill=(108, 116, 126, 255), outline=(90, 98, 108, 255))
c.save(f"{BLOCK}/clay_mold.png")

# melting upgrade: iron casing with a molten mouth
m = Image.new("RGBA", (16, 16), (110, 114, 120, 255))
d = ImageDraw.Draw(m)
for i in range(16):
    d.point((i, 0), fill=(90, 94, 100, 255))
    d.point((i, 15), fill=(90, 94, 100, 255))
    d.point((0, i), fill=(90, 94, 100, 255))
    d.point((15, i), fill=(90, 94, 100, 255))
d.rectangle([3, 6, 12, 13], fill=(60, 62, 66, 255))
d.rectangle([4, 9, 11, 12], fill=(232, 120, 44, 255))
d.rectangle([5, 8, 10, 8], fill=(248, 168, 76, 255))
m.save(f"{BLOCK}/melting_upgrade.png")
print("generated block textures")

# ---------------------------------------------------------------- 4. mold item icons
def mold_icon(face_rgb, wall_rgb, hollow_rgb):
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse([2, 4, 13, 13], fill=wall_rgb + (255,), outline=(60, 60, 64, 255))
    d.ellipse([4, 6, 11, 11], fill=hollow_rgb + (255,))
    return im

mold_icon(None, (168, 176, 184), (120, 128, 138)).save(f"{ITEM}/clay_mold.png")
mold_icon(None, (164, 100, 64), (120, 72, 46)).save(f"{ITEM}/terracotta_mold.png")
print("generated mold icons")

# ---------------------------------------------------------------- 5. assembly table GUI (176x166)
g = Image.new("RGBA", (176, 166), (0, 0, 0, 0))
d = ImageDraw.Draw(g)
# panel
d.rectangle([0, 0, 175, 165], fill=(198, 198, 198, 255))
d.rectangle([0, 0, 175, 165], outline=(85, 85, 85, 255))
d.rectangle([1, 1, 174, 164], outline=(255, 255, 255, 255))
d.rectangle([2, 2, 173, 163], fill=(198, 198, 198, 255))
# darker inner area
d.rectangle([4, 4, 171, 82], fill=(150, 150, 150, 255))
# title is drawn by the screen; leave space
# three input slots (x=44 y=18/42/66 -> slot boxes 36,16 style: vanilla slot = 18px cell)
for sy in (18, 42, 66):
    d.rectangle([35, sy - 1, 52, sy + 16], fill=(139, 139, 139, 255), outline=(55, 55, 55, 255))
    d.line([(36, sy), (51, sy)], fill=(255, 255, 255, 255))
    d.line([(36, sy), (36, sy + 15)], fill=(255, 255, 255, 255))
# arrow
d.rectangle([70, 41, 106, 42], fill=(85, 85, 85, 255))
d.polygon([(104, 34), (114, 41), (104, 49)], fill=(85, 85, 85, 255))
# result slot (big)
d.rectangle([125, 33, 152, 60], fill=(139, 139, 139, 255), outline=(55, 55, 55, 255))
d.rectangle([127, 35, 150, 58], outline=(255, 255, 255, 255))
g.save(f"{GUI}/assembly_table.png")
print("generated assembly table GUI")

# ---------------------------------------------------------------- 6. remove obsolete textures
keep = set(PARTS.keys()) | {"plating_helmet", "plating_chestplate", "plating_leggings", "plating_boots",
                            "attachment_helmet", "attachment_chestplate", "attachment_leggings", "attachment_boots",
                            "lining_helmet", "lining_chestplate", "lining_leggings", "lining_boots",
                            "clay_mold", "terracotta_mold", "modular_guidebook"}
removed = 0
for f in glob.glob(f"{ITEM}/*.png"):
    name = os.path.basename(f)[:-4]
    if name not in keep:
        os.remove(f)
        removed += 1
for f in [f"{BLOCK}/tinker_station_top.png", f"{BLOCK}/tinker_station_side.png", f"{BLOCK}/tinker_station_bottom.png"]:
    if os.path.exists(f):
        os.remove(f)
        removed += 1
for f in glob.glob(f"{RES}/gui/*.png"):
    if os.path.basename(f) in ("tinker_station.png",):
        os.remove(f)
        removed += 1
print(f"removed {removed} obsolete textures")
