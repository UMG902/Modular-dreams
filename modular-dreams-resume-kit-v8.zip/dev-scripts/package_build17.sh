#!/usr/bin/env bash
# Build 17 packaging: fresh deliverables into download/ + refreshed cold-start kit (v4).
set -euo pipefail

WORK=/home/z/my-project
PROJ=$WORK/modular-dreams
DL=$WORK/download
STAGE=$WORK/work/pkg17

rm -rf "$STAGE"; mkdir -p "$STAGE/modular-dreams"

# 1) built jars
cp "$PROJ/build/libs/modular-dreams-1.7.0.jar" "$STAGE/"
cp "$PROJ/build/libs/modular-dreams-1.7.0-sources.jar" "$STAGE/"

# 2) full project tree WITH gradle wrapper + datagen output (kit layout)
cd "$PROJ"
rsync -a --exclude build --exclude .gradle --exclude run --exclude bin \
        src gradle gradlew gradlew.bat gradle.properties build.gradle settings.gradle LICENSE \
        "$STAGE/modular-dreams/" 2>/dev/null

# 3) notes + worklog + dev-scripts
cp "$WORK/BUILD-17-NOTES.txt" "$STAGE/BUILD-17-NOTES.txt"
cp "$WORK/worklog.md" "$STAGE/worklog.md"
cp -r "$WORK/dev-scripts" "$STAGE/dev-scripts"

# 4) B17 FULL zip (everything, one download)
cd "$STAGE"
rm -f "$DL/MODULAR-DREAMS-B17-FULL.zip"
zip -qr "$DL/MODULAR-DREAMS-B17-FULL.zip" .

# 5) bare jars + notes into download/
cp "$STAGE/modular-dreams-1.7.0.jar" "$DL/"
cp "$STAGE/modular-dreams-1.7.0-sources.jar" "$DL/"
cp "$STAGE/BUILD-17-NOTES.txt" "$DL/"

# 6) drop stale build-16 deliverables (user already has and tested b16)
rm -f "$DL"/modular-dreams-1.6.0* "$DL"/MODULAR-DREAMS-B16-FULL.zip \
      "$DL"/MODULAR-DREAMS-RESUME-KIT*.zip "$DL"/BUILD-16-NOTES.txt \
      "$DL"/README-B16.txt "$DL"/index.html "$DL"/RESUME-PROMPT.txt

# 7) cold-start kit v4 (repo edition - same layout as the v3 the user hosts)
KIT=$WORK/work/kit17
rm -rf "$KIT"; mkdir -p "$KIT"
cp -r "$STAGE/." "$KIT/"
cp "$WORK/RESUME-PROMPT.txt" "$KIT/RESUME-PROMPT.txt"
cp "$WORK/README-KIT.txt" "$KIT/README-KIT.txt"
cd "$KIT"
rm -f "$DL/MODULAR-DREAMS-RESUME-KIT-v4.zip"
zip -qr "$DL/MODULAR-DREAMS-RESUME-KIT-v4.zip" .

echo "--- packaged: ---"
python3 - <<'EOF'
import os, hashlib, zipfile
dl = '/home/z/my-project/download'
for f in sorted(os.listdir(dl)):
    p = os.path.join(dl, f)
    h = hashlib.md5(open(p, 'rb').read()).hexdigest()
    print(f"{os.path.getsize(p):>9,} B  md5:{h}  {f}")
for z in ['MODULAR-DREAMS-B17-FULL.zip', 'MODULAR-DREAMS-RESUME-KIT-v4.zip']:
    zz = zipfile.ZipFile(os.path.join(dl, z))
    print(f"{z}: {len(zz.namelist())} entries")
EOF
