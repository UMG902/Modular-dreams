#!/usr/bin/env bash
# Build 20 packaging: fresh deliverables into download/ + refreshed cold-start kit (v7).
set -euo pipefail

WORK=/home/z/my-project
PROJ=$WORK/modular-dreams
DL=$WORK/download
STAGE=$WORK/work/pkg20

rm -rf "$STAGE"; mkdir -p "$STAGE/modular-dreams"

# 1) built jars
cp "$PROJ/build/libs/modular-dreams-1.7.1.jar" "$STAGE/"
cp "$PROJ/build/libs/modular-dreams-1.7.1-sources.jar" "$STAGE/"

# 2) full project tree WITH gradle wrapper + datagen output (kit layout)
cd "$PROJ"
rsync -a --exclude build --exclude .gradle --exclude run --exclude bin \
        src gradle gradlew gradlew.bat gradle.properties build.gradle settings.gradle LICENSE \
        "$STAGE/modular-dreams/" 2>/dev/null

# 3) notes + worklog + dev-scripts
cp "$WORK/BUILD-20-NOTES.txt" "$STAGE/BUILD-20-NOTES.txt"
cp "$WORK/worklog.md" "$STAGE/worklog.md"
cp -r "$WORK/dev-scripts" "$STAGE/dev-scripts"

# 4) B20 FULL zip (everything, one download)
cd "$STAGE"
rm -f "$DL/MODULAR-DREAMS-B20-FULL.zip"
zip -qr "$DL/MODULAR-DREAMS-B20-FULL.zip" .

# 5) bare jars + notes into download/
cp "$STAGE/modular-dreams-1.7.1.jar" "$DL/"
cp "$STAGE/modular-dreams-1.7.1-sources.jar" "$DL/"
cp "$STAGE/BUILD-20-NOTES.txt" "$DL/"

# 6) drop stale build-19 deliverables (user already has and tested b19)
rm -f "$DL"/modular-dreams-1.9.0* "$DL"/MODULAR-DREAMS-B19-FULL.zip \
      "$DL"/MODULAR-DREAMS-RESUME-KIT*.zip "$DL"/BUILD-19-NOTES.txt

# 7) cold-start kit v7 (repo edition - same layout as the v6 the user hosts)
KIT=$WORK/work/kit20
rm -rf "$KIT"; mkdir -p "$KIT"
cp -r "$STAGE/." "$KIT/"
cp "$WORK/RESUME-PROMPT.txt" "$KIT/RESUME-PROMPT.txt"
cp "$WORK/README-KIT.txt" "$KIT/README-KIT.txt"
cd "$KIT"
rm -f "$DL/MODULAR-DREAMS-RESUME-KIT-v7.zip"
zip -qr "$DL/MODULAR-DREAMS-RESUME-KIT-v7.zip" .

echo "--- packaged: ---"
python3 - <<'EOF'
import os, hashlib, zipfile
dl = '/home/z/my-project/download'
for f in sorted(os.listdir(dl)):
    p = os.path.join(dl, f)
    if os.path.isfile(p):
        h = hashlib.md5(open(p, 'rb').read()).hexdigest()
        print(f"{os.path.getsize(p):>9,} B  md5:{h}  {f}")
for z in ['MODULAR-DREAMS-B20-FULL.zip', 'MODULAR-DREAMS-RESUME-KIT-v7.zip']:
    zz = zipfile.ZipFile(os.path.join(dl, z))
    bad = zz.testzip()
    print(f"{z}: {len(zz.namelist())} entries, integrity {'OK' if bad is None else 'FAIL ' + bad}")
EOF
