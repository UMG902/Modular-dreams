#!/usr/bin/env python3
"""Build 17 asset pass: fix mold rendering bugs reported in build-16 testing.

1) INVISIBLE SIDES: every mold block model (2 base + 20 shaped) carried
   "cullface": "down" on its four SIDE faces. Culling is a simple directional
   check (the neighbor BELOW is almost always a solid cube), so all four side
   faces vanished. Remove cullface from north/south/east/west; keep it on the
   bottom face, where it is correct.
2) ITEM-FORM CUTOUT: items/clay_mold.json and items/terracotta_mold.json were
   static "minecraft:model" definitions, so a shaped mold item always showed
   the uncarved model. Rewrite both as "minecraft:select" on the
   modular_dreams:mold_part component (Codec.STRING -> raw part id), with one
   case per shape pointing at the carved block models and a fallback to the
   base model. Format verified against 26.3: ComponentContents (ldc "component"
   dispatch) + vanilla wolf_armor.json (parameterized property = string id +
   flat parameters) + iron_boots.json (select/cases/fallback).

Run from the modular-dreams project root or anywhere - paths are absolute.
"""
import json
import os
import sys

ASSETS = "/home/z/my-project/modular-dreams/src/main/resources/assets/modular_dreams"
BLOCKS = os.path.join(ASSETS, "models", "block")
ITEMS = os.path.join(ASSETS, "items")

# MoldShape enum order (drives blockstate variants too)
SHAPES = [
    "handle", "binding", "pickaxe_head", "axe_head", "shovel_head",
    "hoe_head", "sword_head", "sword_binding", "spear_head", "spear_binding",
]
MOLDS = ["clay_mold", "terracotta_mold"]
SIDE_FACES = ["north", "south", "east", "west"]

fixed_faces = 0
checked = 0
for mold in MOLDS:
    names = [f"{mold}.json"] + [f"{mold}_shaped_{s}.json" for s in SHAPES]
    for name in names:
        path = os.path.join(BLOCKS, name)
        with open(path) as fh:
            model = json.load(fh)
        checked += 1
        for element in model.get("elements", []):
            for face_name, face in element.get("faces", {}).items():
                if face_name in SIDE_FACES and face.get("cullface") == "down":
                    del face["cullface"]
                    fixed_faces += 1
        with open(path, "w") as fh:
            json.dump(model, fh, indent=2)
            fh.write("\n")
print(f"block models: checked {checked}, removed {fixed_faces} bogus side cullfaces")

for mold in MOLDS:
    definition = {
        "model": {
            "type": "minecraft:select",
            "property": "minecraft:component",
            "component": "modular_dreams:mold_part",
            "cases": [
                {
                    "when": shape,
                    "model": {
                        "type": "minecraft:model",
                        "model": f"modular_dreams:block/{mold}_shaped_{shape}",
                    },
                }
                for shape in SHAPES
            ],
            "fallback": {
                "type": "minecraft:model",
                "model": f"modular_dreams:block/{mold}",
            },
        }
    }
    path = os.path.join(ITEMS, f"{mold}.json")
    with open(path, "w") as fh:
        json.dump(definition, fh, indent=2)
        fh.write("\n")
    print(f"item definition: {path} (select, {len(SHAPES)} cases)")

sys.exit(0)
