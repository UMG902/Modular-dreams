#!/usr/bin/env bash
# Self-restarting static file server on the Caddy upstream port (3000).
# Serves /home/z/my-project/download to the platform preview (Caddy :81 -> :3000).
set -u
DL=/home/z/my-project/download
LOG=/home/z/my-project/work/http3000.log
while true; do
  if ! pgrep -f "http.server 3000" >/dev/null 2>&1; then
    echo "$(date -u +%FT%TZ) starting http.server :3000" >> "$LOG"
    nohup python3 -m http.server 3000 --bind 127.0.0.1 --directory "$DL" >> "$LOG" 2>&1 &
  fi
  sleep 10
done
