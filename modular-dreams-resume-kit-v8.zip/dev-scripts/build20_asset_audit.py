#!/usr/bin/env python3
"""Build 20 asset audit - "back to build 17, rod bindings removed only".
Verifies the shipped jar:
  1. version 1.7.1
  2. build-17 tint palette live: static tool defs (decimal RGB) +
     generated part defs (signed ARGB); ZERO build-18/build-19 tint values
     anywhere in the jar
  3. every texture in the jar is byte-identical to the build-17-era sprites
     (reference: git 8d05653 extracted to work/b17_textures)
  4. build-18 regression guard kept: zero rod-binding artifacts, rod handles
     present (the ONE intentional deviation from b17)
  5. build-17 regression: mold select/10-case defs + models intact
"""
import io
import json
import os
import sys
import zipfile

JAR = "/home/z/my-project/modular-dreams/build/libs/modular-dreams-1.7.1.jar"
B17_TEX_DIR = "/home/z/my-project/work/b17_textures"

def signed(hexval):
    return hexval - (1 << 32) if hexval >= (1 << 31) else hexval

def argb(rgb):  # constant tint stored as signed ARGB with alpha FF
    return signed(0xFF000000 | rgb)

# build-17 palette (decimal RGB in static defs)
B17_DEC = {"gold": 16375371, "copper": 15170646, "blaze_rod": 16625711,
           "breeze_rod": 9418440, "iron": 14211288}
# build-18 / build-19 palettes - must appear NOWHERE
FORBIDDEN_DEC = {16766720, 16739642, 16747008, 5232127,          # b18
                 16773447, 16747626, 16765231, 10988773, 15592941}  # b19
B18_RGB = {"gold": 0xFFD700, "copper": 0xFF6D3A, "blaze_rod": 0xFF8A00,
           "breeze_rod": 0x4FD5FF}
B19_RGB = {"gold": 0xFFF147, "copper": 0xFF8C6A, "iron": 0xEDEDED,
           "blaze_rod": 0xFFD12F, "breeze_rod": 0xA7ACE5}
FORBIDDEN_ARGB = {argb(v) for v in B18_RGB.values()} | {argb(v) for v in B19_RGB.values()}
# build-17 ARGB expected in generated part defs
B17_ARGB = {m: argb(rgb) for m, rgb in
            {"gold": 0xF9DE4B, "copper": 0xE77C56, "iron": 0xD8D8D8,
             "blaze_rod": 0xFDB02F, "breeze_rod": 0x8FB6C8}.items()}

fails = []
jar = zipfile.ZipFile(JAR)
names = jar.namelist()

# 1. version
ver = json.loads(jar.read("fabric.mod.json"))["version"]
if ver != "1.7.1":
    fails.append(f"version is {ver}, expected 1.7.1")

# 2a. static tool defs: b17 tints live, no b18/b19 values
for t in ["modular_pickaxe", "modular_axe", "modular_shovel", "modular_hoe",
          "modular_sword", "modular_spear"]:
    d = json.loads(jar.read(f"assets/modular_dreams/items/{t}.json"))
    for layer in d["model"]["layers"]:
        for mkey, variant in layer.get("variants", {}).items():
            val = variant.get("tints", [{}])[0].get("value")
            if val in FORBIDDEN_DEC:
                fails.append(f"{t}: forbidden (b18/b19) tint {val} in {mkey}")
            if mkey in B17_DEC and val != B17_DEC[mkey]:
                fails.append(f"{t}: {mkey} tint {val}, expected b17 {B17_DEC[mkey]}")

# 2b. generated part defs: b17 ARGB live, no b18/b19 ARGB anywhere
item_defs = [n for n in names if n.startswith("assets/modular_dreams/items/")
             and n.endswith(".json")]
checked = 0
for n in sorted(item_defs):
    d = json.loads(jar.read(n))
    tint = d.get("model", {}).get("tints", [{}])[0].get("value")
    if tint is None:
        continue
    if tint in FORBIDDEN_ARGB:
        fails.append(f"{n}: forbidden (b18/b19) ARGB tint {tint}")
    base = os.path.basename(n)[:-5]
    for mat, expected in B17_ARGB.items():
        if base.startswith(mat):
            checked += 1
            if tint != expected:
                fails.append(f"{n}: ARGB {tint}, expected b17 {expected}")
if checked < 32:
    fails.append(f"only {checked} part defs tint-checked, expected 32+")

# 3. textures byte-identical to build-17-era sprites
b17_md5 = {}
for root, _dirs, files in os.walk(B17_TEX_DIR):
    for f in files:
        p = os.path.join(root, f)
        rel = os.path.relpath(p, B17_TEX_DIR)
        import hashlib
        b17_md5[f"assets/modular_dreams/textures/{rel}"] = hashlib.md5(open(p, "rb").read()).hexdigest()
tex_in_jar = [n for n in names if n.startswith("assets/modular_dreams/textures/") and n.endswith(".png")]
missing_ref = [n for n in tex_in_jar if n not in b17_md5]
if missing_ref:
    fails.append(f"jar textures with no b17 reference: {missing_ref}")
for n in tex_in_jar:
    import hashlib
    if n in b17_md5 and hashlib.md5(jar.read(n)).hexdigest() != b17_md5[n]:
        fails.append(f"{n}: sprite differs from build-17 (b19 sprite leaked?)")

# 4. rod bindings STILL gone (the one intentional b18 deviation), handles present
rb = [n for n in names if "rod_binding" in n]
if rb:
    fails.append(f"rod_binding entries present: {rb}")
lang = json.loads(jar.read("assets/modular_dreams/lang/en_us.json"))
if any("rod_binding" in k for k in lang):
    fails.append("rod_binding lang keys present")
for must in ("assets/modular_dreams/items/blaze_rod_handle.json",
             "assets/modular_dreams/items/breeze_rod_handle.json"):
    if must not in names:
        fails.append(f"rod handle def missing: {must}")
# Part Builder recipes for rod bindings must not exist
rb_recipes = [n for n in names if n.startswith("data/modular_dreams/recipe/")
              and "rod_binding" in n]
if rb_recipes:
    fails.append(f"rod binding recipes present: {rb_recipes}")

# 5. molds intact (b17)
for mold in ("clay_mold", "terracotta_mold"):
    d = json.loads(jar.read(f"assets/modular_dreams/items/{mold}.json"))
    if d["model"].get("type") != "minecraft:select" or len(d["model"].get("cases", [])) != 10:
        fails.append(f"{mold}: lost select/10-case structure")
for mold in ("clay_mold", "terracotta_mold"):
    tex = f"assets/modular_dreams/textures/item/{mold}.png"
    if tex not in names:
        fails.append(f"{mold} texture missing")

if fails:
    print("AUDIT FAILED:")
    for f in fails:
        print(" -", f)
    sys.exit(1)
print(f"AUDIT PASSED: {len(names)} entries, v1.7.1, b17 palette+sprites live "
      f"({len(tex_in_jar)} textures byte-identical, {checked} tinted part defs), "
      f"zero b18/b19 tint remnants, rod bindings still gone, rod handles present, molds intact")
