#!/usr/bin/env python3
"""Build 15 GUI texture regeneration.

Both mod GUI textures are rebuilt from the VANILLA furnace panel so they get
the authentic panel bevel, vanilla-style slot cells and a real player
inventory section (the old assembly_table.png had no inventory art and its
slot cells did not match the menu slot coordinates).

Vanilla ground truth (measured from furnace.png, 26.3 client jar):
- slot cell art is 18x18 with its top-left at (slotX-1, slotY-1)
- furnace input cell art top-left: (55, 16)
- player inventory cell rows: art y = 83, 101, 119; hotbar art y = 141
  (slots at y = 84/102/120/142 - the standard machine-GUI layout)
- the progress arrow is a flat #8B8B8B sprite at (80, 35)..(96, 49)
"""
from PIL import Image

RES = "/home/z/my-project/mod/modular-dreams/src/main/resources/assets/modular_dreams/textures/gui"
VAN = "/tmp/vanfx/furnace_panel.png"

van = Image.open(VAN).convert("RGBA")
PANEL_GRAY = (198, 198, 198)  # #C6C6C6 vanilla dialog body

# 18x18 slot cell art, cropped from the vanilla furnace input cell
CELL = van.crop((55, 16, 73, 34))
# vanilla right arrow (#8B8B8B), 17x15
ARROW_R = van.crop((80, 35, 97, 50))


def base_panel():
    """Vanilla panel with the machine area cleared (borders + inventory kept)."""
    img = van.copy()
    px = img.load()
    for y in range(1, 83):
        for x in range(1, 175):
            px[x, y] = (*PANEL_GRAY, 255)
    return img


def paste_cells(img, tops):
    for x, y in tops:
        img.paste(CELL, (x, y))


def draw_arrow_up(img, cx, y0):
    """Blocky up-arrow in the vanilla arrow color, centered on cx."""
    px = img.load()
    color = (139, 139, 139, 255)
    # head: 9 wide, 6 tall
    for dy in range(6):
        half = dy + 1
        for dx in range(-half, half + 1):
            px[cx + dx, y0 + dy] = color
    # shaft: 3 wide, 8 tall
    for dy in range(6, 14):
        for dx in (-1, 0, 1):
            px[cx + dx, y0 + dy] = color


# ---------------------------------------------------------------- melting upgrade
# slots: output (79,18), mold (79,54), inventory 84/102/120, hotbar 142
mu = base_panel()
paste_cells(mu, [(78, 17), (78, 53)])
draw_arrow_up(mu, 86, 37)   # centered x=86 (cell center 78+9=87), arrow 14 tall: 37..50
mu.save(f"{RES}/melting_upgrade.png")

# ---------------------------------------------------------------- assembly table
# slots: inputs (44,18),(44,42),(44,66); result (134,42); inventory 84/102/120, hotbar 142
at = base_panel()
paste_cells(at, [(43, 17), (43, 41), (43, 65), (133, 41)])
at.paste(ARROW_R, (88, 43))  # centered between inputs (end x=61) and result (x=133)
at.save(f"{RES}/container/assembly_table.png")

print("regenerated melting_upgrade.png and container/assembly_table.png")

# ---------------------------------------------------------------- verification
def cells(path):
    img = Image.open(path).convert("RGBA")
    px = img.load()
    found = set()
    for y in range(img.height - 18):
        for x in range(img.width - 18):
            if px[x, y][:3] == (55, 55, 55) and px[x + 1, y][:3] == (55, 55, 55) \
               and px[x, y + 1][:3] == (55, 55, 55) and px[x + 17, y + 17][:3] == (255, 255, 255):
                found.add((x, y))
    return sorted(found)

for name in ("melting_upgrade.png", "container/assembly_table.png"):
    print(name, "cell art top-lefts:", cells(f"{RES}/{name}"))
