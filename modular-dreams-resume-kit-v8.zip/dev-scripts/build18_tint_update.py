#!/usr/bin/env python3
"""Build 18 - vibrant tint palette update for the 6 STATIC tool item
definitions (src/main/resources/assets/modular_dreams/items/modular_*.json).

The datagen-generated part item defs pick up the new colors automatically
(they read material.color()); these 6 hand-maintained files hardcode the
decimal tint values, so they are patched here:

  copper     0xE77C56 (15170646) -> 0xFF6D3A (16739642)
  gold       0xF9DE4B (16375371) -> 0xFFD700 (16766720)
  blaze_rod  0xFDB02F (16625711) -> 0xFF8A00 (16747008)
  breeze_rod 0x8FB6C8 (9418440)  -> 0x4FD5FF (5232127)

Regex-targeted replacement (keeps the file's 1-space indent style), then a
full json.load validation plus per-file occurrence assertions:
  gold/copper: 3 layers each (handle + head + binding)
  rods: 1 layer each (handle ONLY - they are handle-only since build 18)
"""
import json
import re
import sys
from pathlib import Path

ITEMS = Path("/home/z/my-project/modular-dreams/src/main/resources/assets/modular_dreams/items")
TOOLS = ["modular_pickaxe.json", "modular_axe.json", "modular_shovel.json",
         "modular_hoe.json", "modular_sword.json", "modular_spear.json"]

# old decimal -> (new decimal, material key, expected occurrences per tool file)
TINTS = {
    15170646: (16739642, "copper", 3),
    16375371: (16766720, "gold", 3),
    16625711: (16747008, "blaze_rod", 1),
    9418440: (5232127, "breeze_rod", 1),
}
ROD_KEYS = {"blaze_rod", "breeze_rod"}

failures = []
for name in TOOLS:
    path = ITEMS / name
    text = path.read_text()

    # sanity BEFORE patching: rods may only sit inside "part": "handle" layers
    doc = json.loads(text)
    for layer in doc["model"]["layers"]:
        part = layer.get("part", "?")
        for key in layer.get("variants", {}):
            if key in ROD_KEYS and part != "handle":
                failures.append(f"{name}: rod variant '{key}' found in layer '{part}'")

    for old, (new, key, expected) in TINTS.items():
        found = len(re.findall(rf'"value": {old}\b', text))
        if found != expected:
            failures.append(f"{name}: {key} old value {old} found {found}x, expected {expected}")
            continue
        text = text.replace(f'"value": {old}', f'"value": {new}')

    # validate JSON still parses + the new values landed
    doc = json.loads(text)
    seen = {old: 0 for old in TINTS}
    for layer in doc["model"]["layers"]:
        for mkey, variant in layer.get("variants", {}).items():
            val = variant.get("tints", [{}])[0].get("value")
            for old, (new, k, exp) in TINTS.items():
                if val == new:
                    seen[old] += 1
    for old, (new, k, exp) in TINTS.items():
        if seen[old] != exp:
            failures.append(f"{name}: {k} new value {new} found {seen[old]}x, expected {exp}")

    path.write_text(text)
    print(f"PATCHED {name}")

if failures:
    print("\nFAILURES:")
    for f in failures:
        print(" -", f)
    sys.exit(1)

# repo-wide sweep: no old decimal left anywhere in src/main/resources
import subprocess
left = subprocess.run(
    ["grep", "-rl", "-E", "15170646|16375371|16625711|9418440",
     str(Path("/home/z/my-project/modular-dreams/src/main/resources"))],
    capture_output=True, text=True).stdout.strip()
if left:
    print("OLD VALUES STILL PRESENT IN:")
    print(left)
    sys.exit(1)
print("ALL 6 TOOL DEFINITIONS PATCHED - new palette verified, no old decimals left")
