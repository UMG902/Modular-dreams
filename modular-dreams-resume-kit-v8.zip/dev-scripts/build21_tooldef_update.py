#!/usr/bin/env python3
"""Build 21: insert 'diamond' variants (tint 0x4AEDD9 = 4910553) into the
6 hand-maintained tool item defs, in every layer (handle/head/binding),
right after the gold variant. Round-trip check first: load+dump must
reproduce the file byte-exactly (json indent=1) before any edit."""
import json
import sys
from pathlib import Path

ITEMS = Path("/home/z/my-project/modular-dreams/src/main/resources/assets/modular_dreams/items")
TOOLS = ["modular_pickaxe", "modular_axe", "modular_shovel", "modular_hoe",
         "modular_sword", "modular_spear"]
DIAMOND_DEC = 0x4AEDD9  # 4910553 - matches ModMaterials diamond tint
ANCHOR = "gold"

def variant(model_name):
    return {
        "type": "minecraft:model",
        "model": f"modular_dreams:{model_name}",
        "tints": [{"type": "minecraft:constant", "value": DIAMOND_DEC}],
    }

def rebuild_variants(variants):
    """Return a new dict with 'diamond' inserted after the gold key."""
    out = {}
    placed = False
    for k, v in variants.items():
        out[k] = v
        if k == ANCHOR:
            out["diamond"] = None  # placeholder, filled below
            placed = True
    if not placed:
        raise SystemExit(f"no '{ANCHOR}' key among: {list(variants)}")
    model = variants[ANCHOR]["model"]
    out["diamond"] = variant(model.split(":", 1)[1])
    return out

fails = []
for tool in TOOLS:
    p = ITEMS / f"{tool}.json"
    raw = p.read_text()
    data = json.loads(raw)
    # detect indentation + trailing-newline convention
    # (pickaxe/axe/shovel/hoe = 1 space + newline; sword/spear = 2 spaces, no newline)
    indent = None
    for n in (1, 2, 3, 4):
        if json.dumps(data, indent=n).rstrip("\n") == raw.rstrip("\n"):
            indent = n
            break
    if indent is None:
        fails.append(f"{tool}: no matching indent for round-trip, aborting for safety")
        continue
    trailing_nl = raw.endswith("\n")
    layers = data["model"]["layers"]
    for layer in layers:
        part = layer["part"]
        if "diamond" in layer["variants"]:
            continue  # already patched (idempotent)
        layer["variants"] = rebuild_variants(layer["variants"])
        # verify same model as siblings
        model = layer["variants"]["diamond"]["model"]
        siblings = {v["model"] for k, v in layer["variants"].items() if k not in ("diamond",)}
        if siblings != {model}:
            fails.append(f"{tool}/{part}: diamond model {model} != siblings {siblings}")
    p.write_text(json.dumps(data, indent=indent) + ("\n" if trailing_nl else ""))
    print(f"patched {tool} (indent={indent}, trailing_nl={trailing_nl}): layers={[l['part'] for l in layers]}")

if fails:
    print("FAILED:")
    for f in fails:
        print(" -", f)
    sys.exit(1)

# final validation: every tool file parses and has diamond in all layers
for tool in TOOLS:
    d = json.loads((ITEMS / f"{tool}.json").read_text())
    for layer in d["model"]["layers"]:
        val = layer["variants"]["diamond"]["tints"][0]["value"]
        assert val == DIAMOND_DEC, f"{tool}/{layer['part']}: bad tint {val}"
print(f"OK: diamond variant (tint {DIAMOND_DEC}) present in all layers of all 6 tool defs")
