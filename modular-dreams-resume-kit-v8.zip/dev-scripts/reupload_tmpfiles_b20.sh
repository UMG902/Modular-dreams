#!/usr/bin/env bash
# Build 20 delivery: upload the fresh artifacts to tmpfiles.org, extract the
# tokened direct URLs and md5-verify each download against the local file.
set -euo pipefail
DL=/home/z/my-project/download
UA="Mozilla/5.0 (X11; Linux x86_64) Firefox/128.0"

upload () { # $1 = local file -> echoes verified direct URL
  local f="$1" page token
  page=$(curl -sS -m 90 -F "file=@$f" https://tmpfiles.org/api/v1/upload)
  page=$(echo "$page" | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["url"])')
  token=$(curl -sSL -m 30 -A "$UA" "$page" | grep -oE 'https://tmpfiles.org/dl/[^"]*' | head -1)
  [ -n "$token" ] || { echo "FAILED to extract direct URL for $f (page: $page)"; return 1; }
  local tmp; tmp=$(mktemp)
  curl -sSL -m 120 -o "$tmp" "$token"
  if [ "$(md5sum < "$tmp" | cut -d' ' -f1)" = "$(md5sum < "$f" | cut -d' ' -f1)" ]; then
    echo "VERIFIED  $(basename "$f")  $token"
  else
    echo "MD5-MISMATCH  $(basename "$f")  $token"
  fi
  rm -f "$tmp"
}

echo "Upload time: $(date -u +%FT%TZ) (links valid ~60 minutes)"
upload "$DL/modular-dreams-1.7.1.jar"
upload "$DL/MODULAR-DREAMS-B20-FULL.zip"
upload "$DL/MODULAR-DREAMS-RESUME-KIT-v7.zip"
