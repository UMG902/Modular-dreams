#!/usr/bin/env python3
"""Build 21 asset audit - diamond material (v1.10.0).
Verifies the shipped jar:
  1. version 1.10.0
  2. build-17 palette still live everywhere (b20 revert intact) + the new
     diamond tint (decimal 4910553 in the 6 tool defs, signed ARGB
     -11866663 in generated part defs); ZERO build-18/build-19 tints
  3. every pre-existing texture byte-identical to the build-17-era sprites
     (reference: work/b17_textures, extracted from git 8d05653)
  4. diamond complete: 10 part defs, NO part-builder recipes (melt-cast
     like the metals), lang keys (material, 10 part items, Hardened trait)
  5. build-18 regression: zero rod-binding artifacts, rod handles present
  6. build-17 regression: mold select/10-case defs + models intact
"""
import hashlib
import json
import os
import sys
import zipfile

JAR = "/home/z/my-project/modular-dreams/build/libs/modular-dreams-1.10.0.jar"
B17_TEX_DIR = "/home/z/my-project/work/b17_textures"

def signed(hexval):
    return hexval - (1 << 32) if hexval >= (1 << 31) else hexval

def argb(rgb):
    return signed(0xFF000000 | rgb)

B17_DEC = {"gold": 16375371, "copper": 15170646, "blaze_rod": 16625711,
           "breeze_rod": 9418440, "iron": 14211288}
DIAMOND_DEC = 0x4AEDD9          # 4910553
FORBIDDEN_DEC = {16766720, 16739642, 16747008, 5232127,          # b18
                 16773447, 16747626, 16765231, 10988773, 15592941}  # b19
B18_RGB = {"gold": 0xFFD700, "copper": 0xFF6D3A, "blaze_rod": 0xFF8A00,
           "breeze_rod": 0x4FD5FF}
B19_RGB = {"gold": 0xFFF147, "copper": 0xFF8C6A, "iron": 0xEDEDED,
           "blaze_rod": 0xFFD12F, "breeze_rod": 0xA7ACE5}
FORBIDDEN_ARGB = {argb(v) for v in B18_RGB.values()} | {argb(v) for v in B19_RGB.values()}
B17_ARGB = {m: argb(rgb) for m, rgb in
            {"gold": 0xF9DE4B, "copper": 0xE77C56, "iron": 0xD8D8D8,
             "blaze_rod": 0xFDB02F, "breeze_rod": 0x8FB6C8, "diamond": 0x4AEDD9}.items()}

fails = []
jar = zipfile.ZipFile(JAR)
names = jar.namelist()

# 1. version
ver = json.loads(jar.read("fabric.mod.json"))["version"]
if ver != "1.10.0":
    fails.append(f"version is {ver}, expected 1.10.0")

# 2a. static tool defs: b17 tints + diamond variant in EVERY layer
for t in ["modular_pickaxe", "modular_axe", "modular_shovel", "modular_hoe",
          "modular_sword", "modular_spear"]:
    d = json.loads(jar.read(f"assets/modular_dreams/items/{t}.json"))
    for layer in d["model"]["layers"]:
        if "diamond" not in layer["variants"]:
            fails.append(f"{t}: no diamond variant in layer {layer['part']}")
        for mkey, variant in layer.get("variants", {}).items():
            val = variant.get("tints", [{}])[0].get("value")
            if val in FORBIDDEN_DEC:
                fails.append(f"{t}: forbidden (b18/b19) tint {val} in {mkey}")
            expected = DIAMOND_DEC if mkey == "diamond" else B17_DEC.get(mkey)
            if expected is not None and val != expected:
                fails.append(f"{t}: {mkey} tint {val}, expected {expected}")

# 2b. generated part defs: b17/diamond ARGB live, no b18/b19 ARGB anywhere
item_defs = [n for n in names if n.startswith("assets/modular_dreams/items/")
             and n.endswith(".json")]
checked = 0
for n in sorted(item_defs):
    d = json.loads(jar.read(n))
    tint = d.get("model", {}).get("tints", [{}])[0].get("value")
    if tint is None:
        continue
    if tint in FORBIDDEN_ARGB:
        fails.append(f"{n}: forbidden (b18/b19) ARGB tint {tint}")
    base = os.path.basename(n)[:-5]
    for mat, expected in B17_ARGB.items():
        if base.startswith(mat):
            checked += 1
            if tint != expected:
                fails.append(f"{n}: ARGB {tint}, expected {expected}")
if checked < 42:  # 32 b17-palette + 10 diamond
    fails.append(f"only {checked} part defs tint-checked, expected 42+")
if checked != 42:
    fails.append(f"{checked} part defs tint-checked, expected exactly 42 (32 b17 + 10 diamond)")

# 3. textures byte-identical to build-17-era sprites (no new/changed art)
b17_md5 = {}
for root, _dirs, files in os.walk(B17_TEX_DIR):
    for f in files:
        p = os.path.join(root, f)
        rel = os.path.relpath(p, B17_TEX_DIR)
        b17_md5[f"assets/modular_dreams/textures/{rel}"] = hashlib.md5(open(p, "rb").read()).hexdigest()
tex_in_jar = [n for n in names if n.startswith("assets/modular_dreams/textures/") and n.endswith(".png")]
extra_tex = [n for n in tex_in_jar if n not in b17_md5]
if extra_tex:
    fails.append(f"unexpected new/renamed textures in jar: {extra_tex}")
for n in tex_in_jar:
    if n in b17_md5 and hashlib.md5(jar.read(n)).hexdigest() != b17_md5[n]:
        fails.append(f"{n}: sprite differs from build-17")

# 4. diamond completeness
for part in ("pickaxe_head", "axe_head", "shovel_head", "hoe_head", "sword_head",
             "spear_head", "binding", "sword_binding", "spear_binding", "handle"):
    if f"assets/modular_dreams/items/diamond_{part}.json" not in names:
        fails.append(f"missing diamond part def: diamond_{part}")
lang = json.loads(jar.read("assets/modular_dreams/lang/en_us.json"))
if lang.get("material.modular_dreams.diamond") != "Diamond":
    fails.append("diamond material name missing")
if lang.get("trait.modular_dreams.hardened") != "Hardened":
    fails.append("hardened trait name missing")
if "trait.modular_dreams.hardened.desc" not in lang:
    fails.append("hardened trait description missing")
missing_part_lang = [f"item.modular_dreams.diamond_{p}" for p in
                     ("pickaxe_head", "axe_head", "shovel_head", "hoe_head", "sword_head",
                      "spear_head", "binding", "sword_binding", "spear_binding", "handle")
                     if f"item.modular_dreams.diamond_{p}" not in lang]
if missing_part_lang:
    fails.append(f"missing diamond part lang keys: {missing_part_lang}")
dia_recipes = [n for n in names if n.startswith("data/modular_dreams/recipe/")
               and "diamond" in n]
if dia_recipes:
    fails.append(f"diamond must be melt-cast only, found recipes: {dia_recipes}")
parts_recipes = [n for n in names if n.startswith("data/modular_dreams/recipe/parts/") and not n.endswith("/")]
if len(parts_recipes) != 54:
    fails.append(f"part-builder recipes = {len(parts_recipes)}, expected 54")
n_defs = len([n for n in names if n.startswith("assets/modular_dreams/items/") and n.endswith(".json")])
if n_defs != 106:  # 90 generated @b20 + 10 diamond + 6 static tool defs
    fails.append(f"item defs = {n_defs}, expected 106")

# 5. rod bindings STILL gone (b18), handles present
rb = [n for n in names if "rod_binding" in n]
if rb:
    fails.append(f"rod_binding entries present: {rb}")
if any("rod_binding" in k for k in lang):
    fails.append("rod_binding lang keys present")
for must in ("assets/modular_dreams/items/blaze_rod_handle.json",
             "assets/modular_dreams/items/breeze_rod_handle.json"):
    if must not in names:
        fails.append(f"rod handle def missing: {must}")

# 6. molds intact (b17)
for mold in ("clay_mold", "terracotta_mold"):
    d = json.loads(jar.read(f"assets/modular_dreams/items/{mold}.json"))
    if d["model"].get("type") != "minecraft:select" or len(d["model"].get("cases", [])) != 10:
        fails.append(f"{mold}: lost select/10-case structure")

if fails:
    print("AUDIT FAILED:")
    for f in fails:
        print(" -", f)
    sys.exit(1)
print(f"AUDIT PASSED: {len(names)} entries, v1.10.0, b17 palette+sprites intact "
      f"({len(tex_in_jar)} textures byte-identical), diamond complete (10 defs, "
      f"{checked} tinted defs checked, melt-cast only, lang+Hardened recorded), "
      f"part recipes 54, rod bindings still gone, molds intact")
