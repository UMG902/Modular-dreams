#!/usr/bin/env python3
"""Build 19 asset audit - verifies the shipped jar:
  1. version 1.9.0
  2. vanilla-derived tint palette live: static tool defs (decimal RGB) +
     generated part defs (signed ARGB); no build-18 tints left anywhere
  3. new vanilla-derived grayscale sprites in the jar (pixel counts match
     the vanilla factored sprites, values are grayscale)
  4. build-18 regression: zero rod-binding artifacts
  5. build-17 regression: mold select/10-case defs + models intact
"""
import io
import json
import sys
import zipfile

JAR = "/home/z/my-project/modular-dreams/build/libs/modular-dreams-1.9.0.jar"

NEW_DEC = {"gold": 16773447, "copper": 16747626, "blaze_rod": 16765231,
           "breeze_rod": 10988773, "iron": 15592941}
OLD_DEC = {16766720, 16739642, 16747008, 5232127, 14211288,
           15170646, 16375371, 16625711, 9418440}  # b18 + b17 values
NEW_ARGB = {"gold_handle": -3769, "copper_pickaxe_head": -29590,
            "blaze_rod_handle": -11985, "breeze_rod_handle": -5788443,
            "iron_handle": -1184275}
SPRITE_PX = {"pickaxe_head": 37, "axe_head": 33, "shovel_head": 28,
             "hoe_head": 31, "sword_head": 77, "handle": 51}

fails = []
jar = zipfile.ZipFile(JAR)
names = jar.namelist()

# 1. version
ver = json.loads(jar.read("fabric.mod.json"))["version"]
if ver != "1.9.0":
    fails.append(f"version is {ver}, expected 1.9.0")

# 2. tints
for t in ["modular_pickaxe", "modular_axe", "modular_shovel", "modular_hoe",
          "modular_sword", "modular_spear"]:
    d = json.loads(jar.read(f"assets/modular_dreams/items/{t}.json"))
    for layer in d["model"]["layers"]:
        for mkey, variant in layer.get("variants", {}).items():
            val = variant.get("tints", [{}])[0].get("value")
            if val in OLD_DEC:
                fails.append(f"{t}: old tint {val} in {mkey}")
            if mkey in NEW_DEC and val != NEW_DEC[mkey]:
                fails.append(f"{t}: {mkey} tint {val}, expected {NEW_DEC[mkey]}")
for part, argb in NEW_ARGB.items():
    d = json.loads(jar.read(f"assets/modular_dreams/items/{part}.json"))
    val = d["model"]["tints"][0]["value"]
    if val != argb:
        fails.append(f"generated {part}: tint {val}, expected {argb}")

# 3. sprites
from PIL import Image
for name, expected_px in SPRITE_PX.items():
    img = Image.open(io.BytesIO(jar.read(f"assets/modular_dreams/textures/item/{name}.png"))).convert("RGBA")
    px = [p for p in img.getdata() if p[3] > 0]
    if len(px) != expected_px:
        fails.append(f"{name}.png: {len(px)} px, expected {expected_px}")
    if any(max(p[:3]) - min(p[:3]) > 2 for p in px):
        fails.append(f"{name}.png: not grayscale")

# 4. rod bindings still gone
rb = [n for n in names if "rod_binding" in n]
if rb:
    fails.append(f"rod_binding entries: {rb}")
lang = json.loads(jar.read("assets/modular_dreams/lang/en_us.json"))
if any("rod_binding" in k for k in lang):
    fails.append("rod_binding lang keys present")

# 5. molds intact
for mold in ("clay_mold", "terracotta_mold"):
    d = json.loads(jar.read(f"assets/modular_dreams/items/{mold}.json"))
    if d["model"].get("type") != "minecraft:select" or len(d["model"].get("cases", [])) != 10:
        fails.append(f"{mold}: lost select/10-case structure")

if fails:
    print("AUDIT FAILED:")
    for f in fails:
        print(" -", f)
    sys.exit(1)
print(f"AUDIT PASSED: {len(names)} entries, v1.9.0, vanilla-derived palette + sprites live, "
      f"rod bindings still gone, molds intact")
