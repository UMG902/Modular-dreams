#!/usr/bin/env python3
"""Build 12 asset audit: reference resolution + build 12 specifics
(flat mold blocks, melting upgrade GUI, terracotta mold everywhere)."""
import json
import re
import sys
import zipfile

JAR = "/home/z/my-project/mod/modular-dreams/build/libs/modular-dreams-1.2.0.jar"

zf = zipfile.ZipFile(JAR)
names = set(zf.namelist())
missing = []
errors = []

json_files = [n for n in names if n.endswith(".json")]

for name in json_files:
    try:
        text = zf.read(name).decode("utf-8")
        data = json.loads(text)
    except Exception:
        continue

    # 1. item definitions reference models
    if "/items/" in name:
        def walk(node):
            if isinstance(node, dict):
                if "model" in node and isinstance(node["model"], str):
                    model = node["model"]
                    if model.startswith(("minecraft:", "modular_dreams:")):
                        ns, p = model.split(":", 1)
                        target = f"assets/{ns}/models/{p}.json"
                        if target not in names:
                            missing.append((name, model))
                for v in node.values():
                    walk(v)
            elif isinstance(node, list):
                for v in node:
                    walk(v)
        walk(data)

    # 2. blockstates reference block models
    if "/blockstates/" in name:
        def walk_bs(node):
            if isinstance(node, dict):
                if "model" in node and isinstance(node["model"], str):
                    model = node["model"]
                    if model.startswith("modular_dreams:"):
                        ns, p = model.split(":", 1)
                        target = f"assets/{ns}/models/{p}.json"
                        if target not in names:
                            missing.append((name, model))
                for v in node.values():
                    walk_bs(v)
            elif isinstance(node, list):
                for v in node:
                    walk_bs(v)
        walk_bs(data)

    # 3. models reference textures (own namespace only)
    if "/models/" in name and isinstance(data, dict):
        for tex in data.get("textures", {}).values():
            if isinstance(tex, str) and tex.startswith("modular_dreams:"):
                ns, p = tex.split(":", 1)
                target = f"assets/{ns}/textures/{p}.png"
                if target not in names:
                    missing.append((name, tex))

print(f"jar entries: {len(names)}")
print(f"missing references: {len(missing)}")
for src, ref in missing[:20]:
    print(f"  MISSING {ref}   (in {src})")


def load(path):
    return json.loads(zf.read(path).decode("utf-8"))


# --- build 12 specifics ---

# flat mold models: one element, 1 px tall (y 0..1), correct textures
for mold in ("clay_mold", "terracotta_mold"):
    model = load(f"assets/modular_dreams/models/block/{mold}.json")
    elems = model.get("elements", [])
    if len(elems) != 1:
        errors.append(f"{mold} model has {len(elems)} elements, expected 1")
        continue
    el = elems[0]
    if el["from"][1] != 0 or el["to"][1] != 1:
        errors.append(f"{mold} element is {el['from']}..{el['to']}, expected y 0..1 (1 px tall)")
    bs = load(f"assets/modular_dreams/blockstates/{mold}.json")
    if bs.get("variants", {}).get("", {}).get("model") != f"modular_dreams:block/{mold}":
        errors.append(f"{mold} blockstate variant wrong")
    itemdef = load(f"assets/modular_dreams/items/{mold}.json")
    if itemdef.get("model", {}).get("model") != f"modular_dreams:block/{mold}":
        errors.append(f"{mold} item definition does not point at the flat block model")
    for tex in (f"{mold}_top", f"{mold}_side"):
        if f"assets/modular_dreams/textures/block/{tex}.png" not in names:
            errors.append(f"missing texture block/{tex}.png")
    if f"assets/modular_dreams/textures/block/{mold}.png" in names:
        errors.append(f"stale cube texture block/{mold}.png still in the jar")

# melting upgrade GUI texture
if "assets/modular_dreams/textures/gui/melting_upgrade.png" not in names:
    errors.append("missing textures/gui/melting_upgrade.png")

# terracotta mold: loot table, pickaxe tag, lang block name, baking recipe
if "data/modular_dreams/loot_table/blocks/terracotta_mold.json" not in names:
    errors.append("no loot table for terracotta_mold")
tag = load("data/minecraft/tags/block/mineable/pickaxe.json")
if "modular_dreams:terracotta_mold" not in tag.get("values", []):
    errors.append("terracotta_mold missing from mineable/pickaxe")
lang = load("assets/modular_dreams/lang/en_us.json")
if "block.modular_dreams.terracotta_mold" not in lang:
    errors.append("lang missing block.modular_dreams.terracotta_mold")
if "item.modular_dreams.terracotta_mold" in lang:
    errors.append("lang still has stale item.modular_dreams.terracotta_mold")
if "container.modular_dreams.melting_upgrade" not in lang:
    errors.append("lang missing container.modular_dreams.melting_upgrade")
bake = load("data/modular_dreams/recipe/mold_baking.json")
if bake.get("result", {}).get("id") != "modular_dreams:terracotta_mold":
    errors.append("mold_baking recipe result is not the terracotta mold")

# melting furnace still furnace-lookalike + loot + tag (build 11 checks)
bs = load("assets/modular_dreams/blockstates/melting_furnace.json")
if len(bs.get("variants", {})) != 8:
    errors.append("melting_furnace blockstate variant count changed")
if bs.get("variants", {}).get("facing=north,lit=true", {}).get("model") != "minecraft:block/furnace_on":
    errors.append("melting_furnace lit model wrong")
if "assets/modular_dreams/items/melting_furnace.json" in names:
    errors.append("melting_furnace has an item definition but should have none")

# tool layer order preserved: handle -> head -> binding
for tool in ["axe", "hoe", "mace", "pickaxe", "shovel", "spear", "sword"]:
    d = load(f"assets/modular_dreams/items/modular_{tool}.json")
    parts = [l["part"] for l in d["model"]["layers"]]
    expected = [f"{tool}_handle", f"{tool}_head", f"{tool}_binding"]
    if parts != expected:
        errors.append(f"{tool} layers {parts} != {expected}")

print(f"build 12 checks: {len(errors)} errors")
for e in errors:
    print(f"  ERROR {e}")

sys.exit(1 if (missing or errors) else 0)
