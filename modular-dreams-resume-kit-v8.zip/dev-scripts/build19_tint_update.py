#!/usr/bin/env python3
"""Build 19 - vanilla-derived tint palette update for the 6 STATIC tool item
definitions (the datagen part defs follow ModMaterials automatically).

New tints were computed by rank-1 factorization (shared grayscale x tint)
against the REAL vanilla sprites - see build19_vanilla_sprites.py:

  gold       0xFFD700 (16766720) -> 0xFFF147 (16773447)
  copper     0xFF6D3A (16739642) -> 0xFF8C6A (16747626)
  blaze_rod  0xFF8A00 (16747008) -> 0xFFD12F (16765231)
  breeze_rod 0x4FD5FF (5232127)  -> 0xA7ACE5 (10988773)
  iron       0xD8D8D8 (14211288) -> 0xEDEDED (15592941)  [vanilla-close freebie]

Same expectations as build 18: gold/copper/iron in 3 layers per tool file
(handle + head + binding), rods only in the handle layer.
"""
import json
import re
import subprocess
import sys
from pathlib import Path

ITEMS = Path("/home/z/my-project/modular-dreams/src/main/resources/assets/modular_dreams/items")
TOOLS = ["modular_pickaxe.json", "modular_axe.json", "modular_shovel.json",
         "modular_hoe.json", "modular_sword.json", "modular_spear.json"]

TINTS = {
    16766720: (16773447, "gold", 3),
    16739642: (16747626, "copper", 3),
    16747008: (16765231, "blaze_rod", 1),
    5232127: (10988773, "breeze_rod", 1),
    14211288: (15592941, "iron", 3),
}
ROD_KEYS = {"blaze_rod", "breeze_rod"}

failures = []
for name in TOOLS:
    path = ITEMS / name
    text = path.read_text()

    doc = json.loads(text)
    for layer in doc["model"]["layers"]:
        part = layer.get("part", "?")
        for key in layer.get("variants", {}):
            if key in ROD_KEYS and part != "handle":
                failures.append(f"{name}: rod variant '{key}' found in layer '{part}'")

    for old, (new, key, expected) in TINTS.items():
        found = len(re.findall(rf'"value": {old}\b', text))
        if found != expected:
            failures.append(f"{name}: {key} old value {old} found {found}x, expected {expected}")
            continue
        text = text.replace(f'"value": {old}', f'"value": {new}')

    doc = json.loads(text)
    seen = {old: 0 for old in TINTS}
    for layer in doc["model"]["layers"]:
        for mkey, variant in layer.get("variants", {}).items():
            val = variant.get("tints", [{}])[0].get("value")
            for old, (new, k, exp) in TINTS.items():
                if val == new:
                    seen[old] += 1
    for old, (new, k, exp) in TINTS.items():
        if seen[old] != exp:
            failures.append(f"{name}: {k} new value {new} found {seen[old]}x, expected {exp}")

    path.write_text(text)
    print(f"PATCHED {name}")

if failures:
    print("\nFAILURES:")
    for f in failures:
        print(" -", f)
    sys.exit(1)

left = subprocess.run(
    ["grep", "-rl", "-E", "16766720|16739642|16747008|5232127|14211288",
     str(Path("/home/z/my-project/modular-dreams/src/main/resources"))],
    capture_output=True, text=True).stdout.strip()
if left:
    print("OLD VALUES STILL PRESENT IN:")
    print(left)
    sys.exit(1)
print("ALL 6 TOOL DEFINITIONS PATCHED - vanilla-derived palette verified")
